"""Run one MHD nanofluid cavity case and save fields.

Examples
--------
python3 run_case.py --Ra 1e5 --Ha 30 --phi 0.04
python3 run_case.py --Ra 1e5 --Ha 30 --phi 0.04 --mu-model corcione --N 121
python3 run_case.py --Ra 1e5 --Ha 30 --phi 0.04 --k-scale 0.8 --mu-scale 1.3

Pr defaults to the water value from properties.py. k-scale and mu-scale multiply the
enhancement above the base fluid (see properties.nanofluid_ratios), which is how
sampled property uncertainty will enter in the next step.
"""
import argparse
import json
from pathlib import Path

import numpy as np

from properties import WATER, nanofluid_ratios, pure_fluid
from solver import centerline_extrema, solve_cavity


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--Ra", type=float, required=True)
    ap.add_argument("--Ha", type=float, default=0.0)
    ap.add_argument("--phi", type=float, default=0.0)
    ap.add_argument("--Pr", type=float, default=WATER.Pr)
    ap.add_argument("--N", type=int, default=81, help="grid points across the width (odd)")
    ap.add_argument("--k-model", default="maxwell", choices=["maxwell"])
    ap.add_argument("--mu-model", default="brinkman", choices=["brinkman", "einstein", "corcione"])
    ap.add_argument("--d-p", type=float, default=33e-9, help="particle diameter in m (Corcione only)")
    ap.add_argument("--k-scale", type=float, default=1.0)
    ap.add_argument("--mu-scale", type=float, default=1.0)
    ap.add_argument("--out", default="outputs")
    args = ap.parse_args()

    props = (
        nanofluid_ratios(
            args.phi, k_model=args.k_model, mu_model=args.mu_model, d_p=args.d_p,
            k_scale=args.k_scale, mu_scale=args.mu_scale,
        )
        if args.phi > 0
        else pure_fluid()
    )
    res = solve_cavity(Ra=args.Ra, Pr=args.Pr, Ha=args.Ha, props=props, N=args.N, verbose=True)
    ex = centerline_extrema(res)
    print(f"converged={res.converged} steps={res.steps} residual={res.residual:.2e}")
    print(f"Nu hot/cold/mid = {res.Nu_hot:.4f} / {res.Nu_cold:.4f} / {res.Nu_mid:.4f}")
    print(f"|psi|max = {res.psi_abs_max:.4f}  u_max(x=.5) = {ex['u_max']:.3f}  v_max(y=.5) = {ex['v_max']:.3f}")

    out = Path(args.out)
    out.mkdir(exist_ok=True)
    tag = f"Ra{args.Ra:g}_Ha{args.Ha:g}_phi{args.phi:g}_N{args.N}"
    np.savez_compressed(out / f"case_{tag}.npz", x=res.x, y=res.y, psi=res.psi, theta=res.theta, u=res.u, v=res.v)
    (out / f"case_{tag}.json").write_text(
        json.dumps(dict(args=vars(args), props=props, Nu_hot=res.Nu_hot, Nu_cold=res.Nu_cold,
                        Nu_mid=res.Nu_mid, converged=res.converged, steps=res.steps), indent=2)
    )
    print(f"saved {out / ('case_' + tag + '.npz')}")


if __name__ == "__main__":
    main()
