"""P(E > 0) maps from the similarity reduction (water runs + exact rescaling, no learned model), compared with the FNO maps."""
import numpy as np
from theory_common import water_interpolant
from sur_common import load
from properties import nanofluid_ratios
from calibrate import Posterior, property_draws

d = load(); co = d["coef"]; base = d["scenario"] == "base"
lnN_g = water_interpolant(d)
f = lambda X: lnN_g(X[:, 0], 50 * X[:, 1])
z = np.load("gpu_results/outputs/maps.npz")
Ras, Has, phis, K = z["Ra"], z["Ha"], z["phi"], int(z["K"])
post = Posterior.load("outputs/post_k.npz", "k")
out = {}
for c in ("brinkman", "corcione"):
    Pm = np.empty((len(Ras), len(Has), len(phis))); Ext = np.zeros_like(Pm, bool); Em = np.empty_like(Pm)
    for fi, phi in enumerate(phis):
        p = nanofluid_ratios(float(phi), mu_model=c)
        kd = property_draws(post, float(phi), K, np.random.default_rng(2024))[0]
        for r, Ra in enumerate(Ras):
            lra_nf = np.log10(Ra * p["rbeta"] * p["rcp"] / (p["mu"] * kd))
            for h, Ha in enumerate(Has):
                ha_nf = Ha * np.sqrt(p["sigma"] / p["mu"])
                lnb = f(np.array([[np.log10(Ra), Ha / 50]]))[0]
                lnn = f(np.column_stack([lra_nf, np.full(K, ha_nf / 50)]))
                E = kd * np.exp(lnn - lnb) - 1
                Pm[r, h, fi] = (E > 0).mean(); Em[r, h, fi] = E.mean(); Ext[r, h, fi] = (lra_nf < 4).mean() > 0.05
    Pf = z[f"P_pos_{c}"].mean(-1); Ef = z[f"E_mean_{c}"].mean(-1)
    cls = lambda P: np.digitize(P, [0.05, 0.95])          # 0: loss likely, 1: ambiguous, 2: gain likely
    for r, Ra in enumerate(Ras):
        m = ~Ext[r]
        if not m.any():
            print(f"{c:9s} Ra={Ra:.0e}: every cell needs Ra_nf < 1e4 (outside the water runs); not compared")
            continue
        agree = (cls(Pm[r]) == cls(Pf[r]))[m].mean()
        print(f"{c:9s} Ra={Ra:.0e}: cells w/o extrapolation {m.mean():.2f}; class agreement {agree:.3f}; "
              f"|dP| median {np.median(np.abs(Pm[r]-Pf[r])[m]):.3f} max {np.abs(Pm[r]-Pf[r])[m].max():.3f}; "
              f"|dE| median {100*np.median(np.abs(Em[r]-Ef[r])[m]):.2f} pts; frac P>=0.95 red {np.mean(Pm[r][m]>=0.95):.2f} fno {np.mean(Pf[r][m]>=0.95):.2f}")
    out[c] = (Pm, Em, Ext)
np.savez("outputs/theory_maps.npz", **{f"P_{c}": out[c][0] for c in out}, **{f"E_{c}": out[c][1] for c in out},
         **{f"ext_{c}": out[c][2] for c in out})
