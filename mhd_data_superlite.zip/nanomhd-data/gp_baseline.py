"""Scalar Gaussian-process baseline: ln Nu as a function of the five inputs, on the same splits as the neural operators.
Fields are not predicted. Seconds of CPU time; no new simulations."""
import json, warnings
import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
from sur_common import load, split
from sur_deeponet import IN_MU, IN_SD
warnings.filterwarnings("ignore")
d = load(); X = (d["X"] - IN_MU) / IN_SD; y = np.log(d["Nu"]); g = d["group"]; sc = d["scenario"]


def fit_predict(train_idx):
    kern = ConstantKernel(1.0) * Matern(length_scale=np.ones(5), nu=2.5) + WhiteKernel(1e-5, (1e-9, 1e-2))
    gp = GaussianProcessRegressor(kern, normalize_y=True, n_restarts_optimizer=2, random_state=0).fit(X[train_idx], y[train_idx])
    return np.exp(gp.predict(X))


def enhancement(nu, mask):
    idx = np.where(mask)[0]; base = {g[i]: nu[i] for i in idx if sc[i] == "base"}
    return {i: nu[i] / base[g[i]] - 1 for i in idx if sc[i] != "base"}


def metrics(nu, mask):
    Et, Ep = enhancement(d["Nu"], mask), enhancement(nu, mask); ids = sorted(Et)
    et, ep = np.array([Et[i] for i in ids]), np.array([Ep[i] for i in ids])
    return 100 * np.mean(np.abs(ep - et)), np.mean((ep > 0) == (et > 0))


def spread(nu, mask):
    rm, sd = [], []
    for grp in sorted(set(g[mask])):
        mg = g == grp; Et, Ep = enhancement(d["Nu"], mg), enhancement(nu, mg)
        for s in ("brinkman", "corcione"):
            ids = [i for i in Et if sc[i] == s]
            et, ep = np.array([Et[i] for i in ids]), np.array([Ep[i] for i in ids])
            rm.append(100 * np.sqrt(np.mean((et - ep) ** 2))); sd.append(ep.std(ddof=1) / et.std(ddof=1))
    return np.mean(rm), np.mean(sd)


out = {}
tr, te, _, rep = split(d)
nu = fit_predict(np.where(tr)[0])
out["full"] = dict(interp=metrics(nu, te), rep=metrics(nu, rep), spread=spread(nu, rep))
tr_e, te_e, ha_e, rep_e = split(d, extrap=True)
nu_e = fit_predict(np.where(tr_e)[0])
out["full_ex"] = dict(ha=metrics(nu_e, ha_e))
q = []
for seed in range(3):  # same subsampling as sur_pino.py / sur_deeponet.py
    rng = np.random.default_rng(seed); tr_idx = np.where(tr)[0]
    groups = np.unique(g[tr_idx]); rng.shuffle(groups)
    keep = set(groups[: max(1, int(round(0.25 * len(groups))))])
    sub = np.array([i for i in tr_idx if g[i] in keep])
    nq = fit_predict(sub)
    q.append(dict(n=len(sub), interp=metrics(nq, te), rep=metrics(nq, rep), spread=spread(nq, rep)))
out["q25"] = q
print(json.dumps(out, indent=1, default=float))
json.dump(out, open("outputs/gp_baseline.json", "w"), indent=1, default=float)
print("labeled fraction at 25%:", [x["n"] / tr.sum() for x in q])
