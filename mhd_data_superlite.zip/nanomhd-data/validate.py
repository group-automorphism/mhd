"""Validation suite for the MHD nanofluid cavity solver.

Run:  python3 validate.py            (full suite)
      python3 validate.py --fast     (coarser grids, a few minutes)
      python3 validate.py --only benchmark slot

Checks
------
benchmark  Ha = 0, Pr = 0.71 square cavity against the classic differentially heated
           cavity benchmark (Nu, max u on the vertical centerline, max v on the
           horizontal centerline).
slot       Tall cavity, low Ra, mid-height velocity profile against the exact
           Hartmann-type solution. This verifies the Lorentz-force scaling and the
           nanofluid property ratios independently of any literature table.
converge   Grid convergence with observed order and Richardson/GCI estimate for an
           MHD nanofluid case.
physics    Energy balance (hot = cold = mid-section Nu), 180-degree symmetry, and
           monotone suppression of Nu with Ha.
gitt       Optional: rows you paste into benchmarks/gitt_mhd_cavity.csv.

A reference value is only used as a pass/fail gate when it is a standard,
widely published benchmark number. Anything you add from a paper goes in the CSV.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
import time
from pathlib import Path

import numpy as np

from properties import WATER, nanofluid_ratios
from solver import centerline_extrema, solve_cavity

HERE = Path(__file__).resolve().parent
OUT = HERE / "outputs"
OUT.mkdir(exist_ok=True)

# Classic de Vahl Davis (1983) benchmark values, Pr = 0.71, Ha = 0.
# Nu_avg on the hot wall, u_max on x = 0.5, v_max on y = 0.5.
# Verify against the original paper before quoting them in a manuscript.
DAVIS = {
    1e3: dict(Nu=1.118, u_max=3.649, v_max=3.697),
    1e4: dict(Nu=2.243, u_max=16.178, v_max=19.617),
    1e5: dict(Nu=4.519, u_max=34.73, v_max=68.59),
    1e6: dict(Nu=8.800, u_max=64.63, v_max=219.36),
}

RESULTS: list[dict] = []


def record(name: str, ok: bool, detail: str, **extra):
    RESULTS.append(dict(name=name, passed=bool(ok), detail=detail, **extra))
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: {detail}", flush=True)


def timed(fn, *a, **k):
    t0 = time.time()
    out = fn(*a, **k)
    return out, time.time() - t0


# ----------------------------------------------------------------------------
def check_benchmark(fast: bool):
    print("\n== benchmark: Ha = 0, Pr = 0.71 ==")
    for Ra, ref in DAVIS.items():
        # Ra <= 1e5: one grid. Ra = 1e6 has thin boundary layers, so it is judged on two grids:
        # the error must shrink with refinement and end below the tolerance on the finer one.
        grids = [81] if Ra <= 1e5 else ([101, 141] if fast else [121, 181])
        errs = []
        for N in grids:
            res, dt = timed(solve_cavity, Ra=Ra, Pr=0.71, Ha=0.0, N=N)
            ex = centerline_extrema(res)
            e_nu = abs(res.Nu_hot - ref["Nu"]) / ref["Nu"]
            e_u = abs(ex["u_max"] - ref["u_max"]) / ref["u_max"]
            e_v = abs(ex["v_max"] - ref["v_max"]) / ref["v_max"]
            errs.append(e_nu)
            tol = 0.01 if Ra <= 1e5 else (0.015 if fast else 0.01)
            finest = N == grids[-1]
            if finest:
                ok = res.converged and e_nu < tol and e_u < 0.02 and e_v < 0.02
                if len(errs) > 1:
                    ok = ok and errs[-1] < errs[-2]
            else:
                ok = res.converged  # coarser grids are informational; they only need to converge
            record(
                f"benchmark Ra={Ra:.0e} (N={N})",
                ok,
                f"Nu={res.Nu_hot:.4f} (ref {ref['Nu']}, err {e_nu:.2%}), "
                f"u_max={ex['u_max']:.3f} (err {e_u:.2%}), v_max={ex['v_max']:.3f} (err {e_v:.2%}), "
                f"converged={res.converged}, {dt:.0f}s",
            )


# ----------------------------------------------------------------------------
def hartmann_slot_profile(x, Ra_eff, Ha_eff):
    """Exact fully developed vertical velocity between two differentially heated walls
    with a field normal to the walls, zero net flux:
        v = (Ra_eff / Ha_eff^2) [ (1/2 - x) + sinh(Ha_eff (x - 1/2)) / (2 sinh(Ha_eff / 2)) ]
    """
    return (Ra_eff / Ha_eff**2) * (
        (0.5 - x) + np.sinh(Ha_eff * (x - 0.5)) / (2.0 * np.sinh(Ha_eff / 2.0))
    )


def check_slot(fast: bool):
    print("\n== slot: tall cavity vs exact Hartmann-type profile ==")
    N = 41 if fast else 61
    cases = [
        ("pure fluid", 0.0, dict(), 10.0),
        ("Al2O3 phi=0.05", 0.05, nanofluid_ratios(0.05), 10.0),
        ("Al2O3 phi=0.05 Ha=25", 0.05, nanofluid_ratios(0.05), 25.0),
    ]
    fig_data = []
    for label, phi, props, Ha in cases:
        Ra, Pr = 10.0, 0.71
        res, dt = timed(solve_cavity, Ra=Ra, Pr=Pr, Ha=Ha, props=props or None, N=N, aspect=8.0, tmax=8.0)
        p = props if props else dict(sigma=1.0, mu=1.0, rbeta=1.0)
        Ha_eff = Ha * np.sqrt(p["sigma"] / p["mu"])
        Ra_eff = Ra * p["rbeta"] / p["mu"]
        jm = (res.theta.shape[0] - 1) // 2
        v_num = res.v[jm, :]
        v_ex = hartmann_slot_profile(res.x, Ra_eff, Ha_eff)
        err = float(np.max(np.abs(v_num - v_ex)) / np.max(np.abs(v_ex)))
        ok = res.converged and err < 0.02
        record(
            f"slot {label}, Ha={Ha:g} (N={N}, aspect 8)",
            ok,
            f"max profile error {err:.2%} of peak, peak |v| exact {np.max(np.abs(v_ex)):.4e}, "
            f"converged={res.converged}, {dt:.0f}s",
        )
        fig_data.append((label, Ha, res.x.copy(), v_num.copy(), v_ex.copy()))
    return fig_data


# ----------------------------------------------------------------------------
def check_convergence(fast: bool):
    print("\n== converge: grid convergence, MHD nanofluid ==")
    Ra, Ha, phi = 1e5, 20.0, 0.04
    Pr = WATER.Pr
    props = nanofluid_ratios(phi)
    grids = [41, 81, 161] if not fast else [31, 61, 121]
    nus = []
    for N in grids:
        res, dt = timed(solve_cavity, Ra=Ra, Pr=Pr, Ha=Ha, props=props, N=N)
        nus.append(res.Nu_hot)
        print(f"   N={N:4d}: Nu={res.Nu_hot:.5f} (cold {res.Nu_cold:.5f}, mid {res.Nu_mid:.5f}) "
              f"converged={res.converged} steps={res.steps} {dt:.0f}s", flush=True)
    n1, n2, n3 = nus
    r = (grids[1] - 1) / (grids[0] - 1)
    num = n1 - n2
    den = n2 - n3
    if den == 0 or num / den <= 0:
        record("grid convergence", False, f"non-monotone sequence {nus}")
        return None
    p_obs = np.log(num / den) / np.log(r)
    nu_ext = n3 + (n3 - n2) / (r**p_obs - 1.0)
    gci = 1.25 * abs((n3 - n2) / n3) / (r**p_obs - 1.0)
    ok = 1.5 < p_obs < 2.6 and gci < 0.01
    record(
        "grid convergence",
        ok,
        f"Nu = {nus[0]:.4f}, {nus[1]:.4f}, {nus[2]:.4f}; observed order {p_obs:.2f}; "
        f"Richardson Nu = {nu_ext:.4f}; GCI(fine) = {gci:.3%}",
    )
    return dict(grids=grids, Nu=nus, order=float(p_obs), Nu_extrapolated=float(nu_ext), GCI=float(gci))


# ----------------------------------------------------------------------------
def check_physics(fast: bool):
    print("\n== physics: energy balance, symmetry, Ha trend ==")
    N = 61 if fast else 81
    Ra, Ha, phi = 1e5, 20.0, 0.04
    props = nanofluid_ratios(phi)
    res, dt = timed(solve_cavity, Ra=Ra, Pr=WATER.Pr, Ha=Ha, props=props, N=N)
    e_hc = abs(res.Nu_hot - res.Nu_cold) / res.Nu_hot
    e_mid = abs(res.Nu_mid - res.Nu_hot) / res.Nu_hot
    record(
        "energy balance",
        res.converged and e_hc < 2e-3 and e_mid < 0.01,
        f"Nu hot/cold/mid = {res.Nu_hot:.4f}/{res.Nu_cold:.4f}/{res.Nu_mid:.4f}; "
        f"hot-cold {e_hc:.2e}, mid-hot {e_mid:.2%}",
    )
    sym = float(np.max(np.abs(res.theta + res.theta[::-1, ::-1] - 1.0)))
    record("180-degree symmetry", sym < 1e-6, f"max |theta(x,y) + theta(1-x,1-y) - 1| = {sym:.2e}")

    Has = [0.0, 10.0, 30.0, 60.0, 100.0]
    Nt = 101 if fast else 121
    nus = []
    for H in Has:
        r, dt = timed(solve_cavity, Ra=1e5, Pr=0.71, Ha=H, N=Nt)
        nus.append(r.Nu_hot)
        print(f"   Ha={H:5.0f}: Nu={r.Nu_hot:.4f} converged={r.converged} {dt:.0f}s", flush=True)
    mono = all(nus[i] > nus[i + 1] for i in range(len(nus) - 1))
    record(
        "Nu decreases monotonically with Ha",
        mono and nus[-1] >= 1.0 - 2e-3,
        "Nu(Ha) = " + ", ".join(f"{h:g}:{n:.3f}" for h, n in zip(Has, nus)),
    )
    return Has, nus


# ----------------------------------------------------------------------------
def check_gitt(fast: bool):
    path = HERE / "benchmarks" / "gitt_mhd_cavity.csv"
    if not path.exists():
        return
    rows = []
    with path.open() as fh:
        reader = csv.DictReader(line for line in fh if not line.lstrip().startswith("#"))
        rows = [r for r in reader if r.get("Nu_ref", "").strip()]
    if not rows:
        print("\n== gitt: no rows filled in yet (see benchmarks/gitt_mhd_cavity.csv) ==")
        return
    print("\n== gitt: user-supplied literature benchmark rows ==")
    for r in rows:
        ang = float(r.get("angle_deg", 0) or 0)
        if abs(ang) > 1e-9:
            print(f"   skip row (angle {ang} deg): solver supports a horizontal field only")
            continue
        Pr, Ha, ref = float(r["Pr"]), float(r["Ha"]), float(r["Nu_ref"])
        Ra = float(r["Ra"]) if (r.get("Ra") or "").strip() else float(r["Gr"]) * Pr
        # resolution: thin boundary layers at high Ra, Hartmann layers (~1/Ha) at high Ha
        N = 141 if Ra >= 5e5 else 101
        if Ha >= 100:
            N = max(N, 181)
        if fast:
            N = max(61, int(N * 0.7) // 2 * 2 + 1)
        res, dt = timed(solve_cavity, Ra=Ra, Pr=Pr, Ha=Ha, N=N)
        err = abs(res.Nu_hot - ref) / ref
        record(
            f"literature Ra={Ra:.3g} Pr={Pr:g} Ha={Ha:g} (N={N})",
            res.converged and err < 0.03,
            f"Nu={res.Nu_hot:.4f} vs ref {ref} ({err:.2%}), converged={res.converged}, "
            f"{dt:.0f}s, source: {r.get('source', '')}",
        )


# ----------------------------------------------------------------------------
def make_figure(slot_data, Has, nus):
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception as exc:  # pragma: no cover
        print("matplotlib unavailable, skipping figure:", exc)
        return None
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    ax = axes[0]
    for label, Ha, x, vn, ve in slot_data or []:
        (line,) = ax.plot(x, ve, "-", lw=1.8, label=f"exact: {label}, Ha={Ha:g}")
        ax.plot(x[::3], vn[::3], "o", ms=3.5, color=line.get_color())
    ax.set_xlabel("x")
    ax.set_ylabel("v at mid-height")
    ax.set_title("Hartmann-type slot: solver (markers) vs exact (lines)")
    if slot_data:
        ax.legend(fontsize=7)
    ax = axes[1]
    if Has:
        ax.plot(Has, nus, "o-")
    ax.axhline(1.0, color="0.6", ls="--", lw=1)
    ax.set_xlabel("Ha")
    ax.set_ylabel("average Nu")
    ax.set_title("Ra = 1e5, Pr = 0.71: heat transfer suppression")
    fig.tight_layout()
    path = OUT / "validation.png"
    fig.savefig(path, dpi=150)
    return path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fast", action="store_true", help="coarser grids")
    ap.add_argument("--only", nargs="*", choices=["benchmark", "slot", "converge", "physics", "gitt"])
    args = ap.parse_args()
    want = set(args.only) if args.only else {"benchmark", "slot", "converge", "physics", "gitt"}

    t0 = time.time()
    slot_data = Has = nus = conv = None
    if "benchmark" in want:
        check_benchmark(args.fast)
    if "slot" in want:
        slot_data = check_slot(args.fast)
    if "converge" in want:
        conv = check_convergence(args.fast)
    if "physics" in want:
        Has, nus = check_physics(args.fast)
    if "gitt" in want:
        check_gitt(args.fast)

    # partial runs get a suffix so they never overwrite the full-suite results and figure
    suffix = "" if want == {"benchmark", "slot", "converge", "physics", "gitt"} else "_" + "_".join(sorted(want))
    fig = make_figure(slot_data, Has, nus) if (slot_data or Has) else None
    if fig and suffix:
        fig = fig.rename(OUT / f"validation{suffix}.png")
    npass = sum(r["passed"] for r in RESULTS)
    print(f"\n{npass}/{len(RESULTS)} checks passed in {time.time() - t0:.0f}s")
    res_path = OUT / f"validation_results{suffix}.json"
    res_path.write_text(json.dumps(dict(results=RESULTS, convergence=conv), indent=2))
    print(f"results: {res_path}" + (f"\nfigure:  {fig}" if fig else ""))
    sys.exit(0 if npass == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
