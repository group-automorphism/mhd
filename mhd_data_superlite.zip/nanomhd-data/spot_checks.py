"""Solver check of the surrogate where it was never trained: viscosity ratios between the two closures.

Runs the solver for a small set of (Ra, Ha) at phi = 0.04 with mu* set between Brinkman and Corcione, plus the
water baselines, then compares the enhancement E with the FNO surrogates.
    python spot_checks.py --models fno_full_s0 fno_full_s1 fno_full_s2 --workers 8
Writes outputs/spot_checks.csv.
"""
import argparse, csv, pickle
from multiprocessing import Pool
import numpy as np
from properties import WATER, nanofluid_ratios, mu_brinkman
from solver import solve_cavity
from ensemble import choose_N

PHI = 0.04


def k_median():
    """Posterior median conductivity ratio at PHI, from the same draws as sur_maps.py."""
    from calibrate import Posterior, property_draws
    post = Posterior.load("outputs/post_k.npz", "k")
    return float(np.median(property_draws(post, PHI, 400, np.random.default_rng(2024))[0]))


def cases(quick=False):
    K_MED = k_median()
    out = []
    for Ra in ((1e4,) if quick else (1e4, 1e5, 1e6)):
        for Ha in (0.0, 50.0):
            out.append(dict(Ra=Ra, Ha=Ha, phi=0.0, k=1.0, mu=1.0, kind="base"))
            for mu in (1.25, 1.40):
                out.append(dict(Ra=Ra, Ha=Ha, phi=PHI, k=K_MED, mu=mu, kind="nf"))
    return out


def run(c):
    if c["kind"] == "base":
        props = nanofluid_ratios(0.0)
    else:
        kc = nanofluid_ratios(PHI)["k"]
        props = nanofluid_ratios(PHI, mu_model="brinkman", k_scale=(c["k"] - 1) / (kc - 1),
                                 mu_scale=(c["mu"] - 1) / (mu_brinkman(PHI) - 1))
    res = solve_cavity(Ra=c["Ra"], Pr=WATER.Pr, Ha=c["Ha"], props=props, N=choose_N(c["Ra"], c["Ha"]))
    return dict(c, Nu=res.Nu_hot, converged=bool(res.converged), k_used=props["k"], mu_used=props["mu"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", nargs="+", required=True)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--quick", action="store_true", help="Ra = 1e4 only (pipeline test)")
    args = ap.parse_args()
    cs = cases(args.quick)
    with Pool(min(args.workers, len(cs))) as pool:
        res = pool.map(run, cs)
    import jax, jax.numpy as jnp
    from sur_common import load, split
    from sur_deeponet import fit_psi_scale, IN_MU, IN_SD
    from sur_pino import forward
    d = load(); tr, _, _, _ = split(d)
    psi_fn, _ = fit_psi_scale(d["X"][tr], d["psi"][tr])
    X = np.array([[np.log10(r["Ra"]), r["Ha"], r["phi"], r["k_used"], r["mu_used"]] for r in res], np.float32)
    nus = []
    for m in args.models:
        p = jax.tree_util.tree_map(jnp.asarray, pickle.load(open(f"outputs/sur/{m}_params.pkl", "rb")))
        nus.append(np.exp(np.asarray(forward(p, jnp.asarray((X - IN_MU) / IN_SD), jnp.asarray(psi_fn(X)))[3])))
    nus = np.array(nus)                                             # (M, n)
    base = {(r["Ra"], r["Ha"]): i for i, r in enumerate(res) if r["kind"] == "base"}
    rows = []
    for i, r in enumerate(res):
        if r["kind"] != "nf":
            continue
        b = base[(r["Ra"], r["Ha"])]
        Es = r["Nu"] / res[b]["Nu"] - 1
        Ep = nus[:, i] / nus[:, b] - 1
        rows.append(dict(Ra=r["Ra"], Ha=r["Ha"], phi=r["phi"], k=round(r["k_used"], 4), mu=round(r["mu_used"], 4),
                         E_solver=round(Es, 5), E_sur_mean=round(float(Ep.mean()), 5), E_sur_sd=round(float(Ep.std()), 5),
                         err_points=round(100 * (float(Ep.mean()) - Es), 3), converged=r["converged"] and res[b]["converged"]))
    with open("outputs/spot_checks.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    for r in rows:
        print(r)
    e = np.array([r["err_points"] for r in rows])
    print(f"mean abs error {np.abs(e).mean():.2f} points, max {np.abs(e).max():.2f}")


if __name__ == "__main__":
    main()
