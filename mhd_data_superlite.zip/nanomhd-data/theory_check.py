"""Post-processing of existing solver results (no new simulations).

Similarity reduction: within the single-phase constant-property model, Nu_nf = k* N(Ra_nf, Pr_nf, Ha_nf), with
  Ra_nf = Ra (rho beta)* (rho c_p)* / (mu* k*),  Pr_nf = Pr mu* (rho c_p)* / (rho* k*),  Ha_nf = Ha sqrt(sigma*/mu*),
and N the Nusselt function of a pure fluid. Test: interpolate N(Ra, Ha) from the 135 water runs (Pr fixed), predict every
nanofluid run, and compare with the solver.
"""
import json
import numpy as np
from theory_common import water_interpolant
from sur_common import load

d = load()
X, Nu, co, sc, grp = d["X"], d["Nu"], d["coef"], d["scenario"], d["group"]
Ra, Ha, k, rcp, mu, rho, rb, sg = co.T
base = sc == "base"
print("water runs:", base.sum(), " nanofluid runs:", (~base).sum())

lnN = water_interpolant(d)
# leave-one-out error of the interpolant itself (refits the GP once per water run)
from sklearn.base import clone
co_b = co[base]; P = np.column_stack([np.log10(co_b[:, 0]), co_b[:, 1] / 100.0]); y = np.log(Nu[base])
loo = []
for i in range(len(P)):
    m = np.ones(len(P), bool); m[i] = False
    gp = clone(lnN.gp).set_params(kernel=lnN.gp.kernel_, optimizer=None).fit(P[m], y[m])
    loo.append(abs(np.exp(gp.predict(P[i:i+1])[0] - y[i]) - 1))
loo = np.array(loo)
print(f"water-Nu interpolant leave-one-out: median {100*np.median(loo):.2f}%  p90 {100*np.percentile(loo,90):.2f}%  max {100*loo.max():.2f}%")
f = lambda F: lnN(F[:, 0], F[:, 1])
def feats(lra, ha):
    return np.column_stack([lra, ha])

lam = rb * rcp / (mu * k)
Ra_nf = Ra * lam
Ha_nf = Ha * np.sqrt(sg / mu)
Pr_ratio = mu * rcp / (rho * k)
nf = ~base
Nu_pred = k * np.exp(f(feats(np.log10(Ra_nf), Ha_nf)))
inside = np.log10(Ra_nf) >= 4.0
# enhancement relative to the paired water run
base_nu = {g: Nu[i] for i, g in enumerate(grp) if sc[i] == "base"}
bn = np.array([base_nu[g] for g in grp])
E_sol = Nu / bn - 1
E_red = Nu_pred / bn - 1
err = 100 * (E_red - E_sol)
for name, m in (("all nanofluid", nf), ("Ra_nf >= 1e4 (no extrapolation)", nf & inside), ("Ra_nf < 1e4", nf & ~inside)):
    e = np.abs(err[m])
    print(f"{name:34s} n={m.sum():3d}  |E error| median {np.median(e):.2f} pts  p90 {np.percentile(e,90):.2f}  max {e.max():.2f}  sign agree {np.mean((E_red[m]>0)==(E_sol[m]>0)):.3f}")
print(f"Pr_nf/Pr range over nanofluid runs: {Pr_ratio[nf].min():.3f}-{Pr_ratio[nf].max():.3f}")
# error vs Pr ratio (residual attributable to Pr dependence and interpolation)
m = nf & inside
print("corr(error, ln Pr ratio) =", np.corrcoef(err[m], np.log(Pr_ratio[m]))[0, 1].round(3))

# viscosity elasticity: finite difference from paired Brinkman/Corcione runs vs prediction -(a + b/2)
def dlnN(lra, ha, h=1e-3):
    a = (f(feats(lra + h, ha)) - f(feats(lra - h, ha))) / (2 * h) / np.log(10)        # d ln N / d ln Ra
    hb = np.maximum(ha * 1e-3, 1e-6)
    b = ha * (f(feats(lra, ha + hb)) - f(feats(lra, np.maximum(ha - hb, 0)))) / (hb + np.minimum(hb, ha))  # d ln N / d ln Ha
    return a, b
rows = []
for g in np.unique(grp[nf]):
    if not g.startswith("S:"):
        continue
    ib = np.where((grp == g) & (sc == "brinkman"))[0][0]; ic = np.where((grp == g) & (sc == "corcione"))[0][0]
    s_fd = np.log(Nu[ic] / Nu[ib]) / np.log(mu[ic] / mu[ib])
    # prediction at the geometric midpoint of the two nanofluids
    lra = 0.5 * (np.log10(Ra_nf[ib]) + np.log10(Ra_nf[ic])); ha = np.sqrt(Ha_nf[ib] * Ha_nf[ic])
    a, b = dlnN(np.array([lra]), np.array([ha]))
    rows.append((Ra[ib], Ha[ib], X[ib, 2], s_fd, -(a[0] + b[0] / 2), a[0], b[0], lra >= 4))
R = np.array(rows, dtype=float)
ok = R[:, 7] > 0
print(f"elasticity d ln Nu / d ln mu*: finite-difference vs -(a + b/2): corr {np.corrcoef(R[ok,3], R[ok,4])[0,1]:.3f}, "
      f"MAE {np.mean(np.abs(R[ok,3]-R[ok,4])):.3f}, range of FD {R[ok,3].min():.3f}..{R[ok,3].max():.3f}  (n={ok.sum()})")
x = R[:, 1] / R[:, 0] ** 0.25
for lo, hi in ((0, 0.5), (0.5, 1), (1, 2), (2, 4), (4, 12)):
    m = ok & (x >= lo) & (x < hi)
    if m.sum():
        print(f"  Ha/Ra^(1/4) in [{lo},{hi}): n={m.sum():2d}  elasticity FD median {np.median(R[m,3]):.3f}  pred median {np.median(R[m,4]):.3f}")
np.save("outputs/theory_elasticity.npy", R)
np.savez("outputs/theory_reduction.npz", E_sol=E_sol[nf], E_red=E_red[nf], inside=inside[nf], Ra=Ra[nf], Ha=Ha[nf],
         phi=X[nf, 2], scen=sc[nf], Pr_ratio=Pr_ratio[nf])
# Ha = 0 local exponent of the water Nusselt function
for lra in (4.0, 4.5, 5.0, 5.5, 6.0):
    a, b = dlnN(np.array([lra]), np.array([0.0]))
    print(f"  n = d ln N/d ln Ra at Ra=1e{lra}, Ha=0: {a[0]:.3f}")

# ---- like-for-like comparison with the FNO on the interpolation split ----
from sur_common import split
tr, te, _, _ = split(d)
lnN_tr = water_interpolant(d, mask=tr)
Ep = k * np.exp(lnN_tr(np.log10(Ra_nf), Ha_nf)) / np.exp(lnN_tr(np.log10(Ra), Ha)) - 1
mt = te & nf
e = 100 * np.abs(Ep - E_sol)
print(f"[train-only water fit, {lnN_tr.n} runs] held-out nanofluid runs n={mt.sum()}: mean {e[mt].mean():.3f} median {np.median(e[mt]):.3f}; "
      f"in range n={(mt & inside).sum()} mean {e[mt & inside].mean():.3f}; sign agree {np.mean((Ep[mt] > 0) == (E_sol[mt] > 0)):.3f}")
import json
M = json.load(open("gpu_results/outputs/sur/metrics.json"))
print("FNO interpolation E MAE per seed:", [round(M[f"fno_full_s{s}"]["test"]["E_mae_points"], 3) for s in range(3)])
# ---- Ha = 0 edge ----
h0 = nf & inside & (Ha < 5)
print(f"Ha<5 runs n={h0.sum()}: mean |err| {np.abs(err[h0]).mean():.2f}, signed {err[h0].mean():+.2f} pts; Ha>=5 median {np.median(np.abs(err[nf & inside & (Ha >= 5)])):.3f}")
# ---- spot checks (solver runs between the closures) ----
import csv
from properties import nanofluid_ratios
for r in csv.DictReader(open("gpu_results/outputs/spot_checks.csv")):
    p = nanofluid_ratios(float(r["phi"]))
    kk, mm, Ra0, Ha0 = float(r["k"]), float(r["mu"]), float(r["Ra"]), float(r["Ha"])
    Er = kk * np.exp(lnN(np.log10(Ra0 * p["rbeta"] * p["rcp"] / (mm * kk)), Ha0 * np.sqrt(p["sigma"] / mm))[0] - lnN(np.log10(Ra0), Ha0)[0]) - 1
    print(f"  spot Ra={Ra0:.0e} Ha={Ha0:.0f} mu={mm}: solver {100*float(r['E_solver']):+.2f}  reduction {100*Er:+.2f}  FNO {100*float(r['E_sur_mean']):+.2f}")
