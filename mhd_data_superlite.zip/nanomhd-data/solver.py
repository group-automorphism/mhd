"""2D MHD natural convection of a nanofluid in a differentially heated cavity.

Model
-----
Single-phase Boussinesq nanofluid, laminar, low magnetic Reynolds number, with a
uniform horizontal magnetic field B0 along x. The Lorentz force is
F = (0, -sigma_nf B0^2 v). Left wall hot (theta = 1), right wall cold
(theta = 0), top and bottom adiabatic, no slip everywhere.

Scales: length L (cavity width), velocity alpha_f / L, time L^2 / alpha_f,
temperature DeltaT. Parameters use base-fluid values:
    Ra = g beta_f DeltaT L^3 / (nu_f alpha_f),  Pr = nu_f / alpha_f,
    Ha = B0 L sqrt(sigma_f / mu_f).

With property ratios (star quantities, nanofluid / base fluid):
    theta_t + u.grad(theta)   = (k*/rcp*) lap(theta)
    omega_t + u.grad(omega)   = Pr (mu*/rho*) lap(omega)
                                + Ra Pr (rbeta*/rho*) theta_x
                                - Ha^2 Pr (sigma*/rho*) v_x
    lap(psi) = -omega,  u = psi_y,  v = -psi_x,  omega = v_x - u_y

Numerics
--------
Second-order finite differences on a uniform grid, vorticity at walls from
Thom's formula, implicit diffusion with fast transforms (DST-I for Dirichlet,
DCT-I for the adiabatic walls) so there are no matrix factorizations, and
variable-step Adams-Bashforth 2 for convection and the Lorentz term. The
buoyancy term uses the updated temperature. The march to steady state is in
pseudo-physical time and the converged field does not depend on the time scheme.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy.fft import dct, dst, idct, idst

_trapz = getattr(np, "trapezoid", None) or np.trapz  # NumPy 2 renamed trapz

from properties import pure_fluid


@dataclass
class Result:
    x: np.ndarray
    y: np.ndarray
    psi: np.ndarray
    omega: np.ndarray
    theta: np.ndarray
    u: np.ndarray
    v: np.ndarray
    Nu_hot: float
    Nu_cold: float
    Nu_mid: float
    converged: bool
    steps: int
    t: float
    residual: float
    params: dict = field(default_factory=dict)

    @property
    def psi_abs_max(self) -> float:
        return float(np.max(np.abs(self.psi)))


# ----------------------------------------------------------------------------
# fast transforms
# ----------------------------------------------------------------------------
def _dirichlet_eigs(n: int, h: float) -> np.ndarray:
    k = np.arange(1, n + 1)
    return (2.0 * np.cos(np.pi * k / (n + 1)) - 2.0) / h**2


def _neumann_eigs(n: int, h: float) -> np.ndarray:
    k = np.arange(n)
    return (2.0 * np.cos(np.pi * k / (n - 1)) - 2.0) / h**2


def _dst2(a):
    return dst(dst(a, type=1, axis=0), type=1, axis=1)


def _idst2(a):
    return idst(idst(a, type=1, axis=0), type=1, axis=1)


# ----------------------------------------------------------------------------
# finite-difference helpers (arrays are indexed [j (y), i (x)])
# ----------------------------------------------------------------------------
def _ddx(f, h):
    out = np.zeros_like(f)
    out[:, 1:-1] = (f[:, 2:] - f[:, :-2]) / (2.0 * h)
    return out


def _ddy(f, h):
    out = np.zeros_like(f)
    out[1:-1, :] = (f[2:, :] - f[:-2, :]) / (2.0 * h)
    return out


def _velocity(psi, h):
    u = _ddy(psi, h)
    v = -_ddx(psi, h)
    # no slip: exactly zero on all walls
    u[0, :] = u[-1, :] = u[:, 0] = u[:, -1] = 0.0
    v[0, :] = v[-1, :] = v[:, 0] = v[:, -1] = 0.0
    return u, v


def _thom_walls(omega, psi, h):
    """Wall vorticity from Thom's formula with psi = 0 on walls."""
    omega[:, 0] = -2.0 * psi[:, 1] / h**2
    omega[:, -1] = -2.0 * psi[:, -2] / h**2
    omega[0, :] = -2.0 * psi[1, :] / h**2
    omega[-1, :] = -2.0 * psi[-2, :] / h**2
    omega[0, 0] = omega[0, -1] = omega[-1, 0] = omega[-1, -1] = 0.0


def nusselt_numbers(theta, u, rcp, k, h, aspect):
    """Average Nusselt numbers on hot wall, cold wall and the mid vertical section.

    Nu = -(k*) dtheta/dx averaged over the wall (heat flux in units of k_f DeltaT / L
    divided by the conduction value for the base fluid). The mid-section value adds
    the advective flux and must agree with the wall values at steady state.
    """
    ny, nx = theta.shape
    dth_hot = (-3.0 * theta[:, 0] + 4.0 * theta[:, 1] - theta[:, 2]) / (2.0 * h)
    dth_cold = (3.0 * theta[:, -1] - 4.0 * theta[:, -2] + theta[:, -3]) / (2.0 * h)
    Nu_hot = _trapz(-k * dth_hot, dx=h) / aspect
    Nu_cold = _trapz(-k * dth_cold, dx=h) / aspect
    im = (nx - 1) // 2
    dth_mid = (theta[:, im + 1] - theta[:, im - 1]) / (2.0 * h)
    flux = rcp * u[:, im] * theta[:, im] - k * dth_mid
    Nu_mid = _trapz(flux, dx=h) / aspect
    return float(Nu_hot), float(Nu_cold), float(Nu_mid)


def solve_cavity(
    Ra: float,
    Pr: float,
    Ha: float = 0.0,
    props: dict | None = None,
    N: int = 81,
    aspect: float = 1.0,
    tol: float = 1e-7,
    tmax: float = 5.0,
    max_steps: int = 400_000,
    cfl: float = 0.25,
    wall_cap: float = 1.0,
    verbose: bool = False,
) -> Result:
    """March to steady state and return the converged fields.

    N is the number of grid points across the width (odd). aspect = height / width.
    props are nanofluid/base ratios with keys rho, rcp, rbeta, k, mu, sigma
    (see properties.nanofluid_ratios); default is the pure base fluid.
    """
    if N % 2 == 0:
        raise ValueError("N must be odd so the mid-section lies on a grid line")
    p = dict(pure_fluid())
    if props:
        p.update(props)

    h = 1.0 / (N - 1)
    nx = N
    ny = int(round((N - 1) * aspect)) + 1
    x = np.linspace(0.0, 1.0, nx)
    y = np.linspace(0.0, aspect, ny)

    kappa_T = p["k"] / p["rcp"]
    kappa_w = Pr * p["mu"] / p["rho"]
    c_buoy = Ra * Pr * p["rbeta"] / p["rho"]
    c_lor = Ha**2 * Pr * p["sigma"] / p["rho"]

    # eigenvalues for the implicit solves
    lam_x_d = _dirichlet_eigs(nx - 2, h)          # Dirichlet in x (theta and omega)
    lam_y_d = _dirichlet_eigs(ny - 2, h)          # Dirichlet in y (omega, psi)
    lam_y_n = _neumann_eigs(ny, h)                # adiabatic in y (theta)
    L_psi = lam_y_d[:, None] + lam_x_d[None, :]
    L_w = lam_y_d[:, None] + lam_x_d[None, :]
    L_T = lam_y_n[:, None] + lam_x_d[None, :]

    # initial state: conduction profile, fluid at rest
    theta = np.tile(1.0 - x, (ny, 1))
    omega = np.zeros((ny, nx))
    psi = np.zeros((ny, nx))
    u = np.zeros((ny, nx))
    v = np.zeros((ny, nx))

    dt_prev = None
    dt = 1e-6
    f_theta_prev = None
    f_omega_prev = None
    t = 0.0
    converged = False
    residual = np.inf
    step = 0

    dt_diff_cap = 0.02  # keep pseudo-time steps modest for accuracy of transients
    dt_lor_cap = 0.5 / c_lor if c_lor > 0 else np.inf
    # lagged Thom wall vorticity + implicit diffusion is only stable for dt ~ h^2 / kappa
    dt_wall_cap = wall_cap * h**2 / max(kappa_w, kappa_T)

    while step < max_steps and t < tmax:
        # ---- explicit terms at level n
        conv_T = np.zeros_like(theta)
        conv_T[1:-1, 1:-1] = -(
            u[1:-1, 1:-1] * _ddx(theta, h)[1:-1, 1:-1]
            + v[1:-1, 1:-1] * _ddy(theta, h)[1:-1, 1:-1]
        )
        f_theta = conv_T

        f_omega = np.zeros_like(omega)
        f_omega[1:-1, 1:-1] = -(
            u[1:-1, 1:-1] * _ddx(omega, h)[1:-1, 1:-1]
            + v[1:-1, 1:-1] * _ddy(omega, h)[1:-1, 1:-1]
        ) - c_lor * _ddx(v, h)[1:-1, 1:-1]

        # ---- time step
        umax = max(float(np.max(np.abs(u))), float(np.max(np.abs(v))), 1.0)
        dt_new = min(dt_diff_cap, cfl * h / umax, dt_lor_cap, dt_wall_cap)
        if dt_prev is None:
            dt_new = min(dt_new, 1e-4)  # gentle start: buoyancy accelerates the fluid from rest
        else:
            dt_new = min(dt_new, 1.05 * dt_prev)
        dt = dt_new
        r = 0.0 if dt_prev is None else dt / dt_prev

        if f_theta_prev is None:
            ft_ext, fw_ext = f_theta, f_omega
        else:
            ft_ext = (1.0 + 0.5 * r) * f_theta - 0.5 * r * f_theta_prev
            fw_ext = (1.0 + 0.5 * r) * f_omega - 0.5 * r * f_omega_prev

        # ---- temperature: implicit diffusion, Dirichlet left/right, adiabatic top/bottom
        rhs = theta[:, 1:-1] + dt * ft_ext[:, 1:-1]
        rhs[:, 0] += kappa_T * dt / h**2 * theta[:, 0]
        rhs[:, -1] += kappa_T * dt / h**2 * theta[:, -1]
        rhat = dct(dst(rhs, type=1, axis=1), type=1, axis=0)
        that = rhat / (1.0 - kappa_T * dt * L_T)
        theta_new = theta.copy()
        theta_new[:, 1:-1] = idst(idct(that, type=1, axis=0), type=1, axis=1)

        # ---- vorticity with Thom wall values at level n
        _thom_walls(omega, psi, h)
        buoy = c_buoy * _ddx(theta_new, h)
        rhs_w = omega[1:-1, 1:-1] + dt * (fw_ext[1:-1, 1:-1] + buoy[1:-1, 1:-1])
        rhs_w[:, 0] += kappa_w * dt / h**2 * omega[1:-1, 0]
        rhs_w[:, -1] += kappa_w * dt / h**2 * omega[1:-1, -1]
        rhs_w[0, :] += kappa_w * dt / h**2 * omega[0, 1:-1]
        rhs_w[-1, :] += kappa_w * dt / h**2 * omega[-1, 1:-1]
        what = _dst2(rhs_w) / (1.0 - kappa_w * dt * L_w)
        omega_new = omega.copy()
        omega_new[1:-1, 1:-1] = _idst2(what)

        # ---- streamfunction
        psi_new = np.zeros_like(psi)
        psi_new[1:-1, 1:-1] = _idst2(-_dst2(omega_new[1:-1, 1:-1]) / L_psi)
        _thom_walls(omega_new, psi_new, h)
        u_new, v_new = _velocity(psi_new, h)

        # ---- bookkeeping
        if step % 25 == 0:
            res_T = float(np.max(np.abs(theta_new - theta))) / dt
            psi_scale = max(float(np.max(np.abs(psi_new))), 1e-12)
            res_psi = float(np.max(np.abs(psi_new - psi))) / (dt * psi_scale)
            residual = max(res_T, res_psi)
            if not np.isfinite(residual):
                raise FloatingPointError(
                    f"solution diverged at step {step}, t={t:.4g}, dt={dt:.3g}"
                )
            if verbose and step % 2500 == 0:
                print(f"  step {step:7d} t={t:8.4f} dt={dt:.2e} umax={umax:9.3f} res={residual:.2e}")
            if residual < tol and t > 0.05:
                converged = True
                theta, omega, psi, u, v = theta_new, omega_new, psi_new, u_new, v_new
                t += dt
                step += 1
                break

        f_theta_prev, f_omega_prev = f_theta, f_omega
        theta, omega, psi, u, v = theta_new, omega_new, psi_new, u_new, v_new
        dt_prev = dt
        t += dt
        step += 1

    Nu_hot, Nu_cold, Nu_mid = nusselt_numbers(theta, u, p["rcp"], p["k"], h, aspect)
    return Result(
        x=x, y=y, psi=psi, omega=omega, theta=theta, u=u, v=v,
        Nu_hot=Nu_hot, Nu_cold=Nu_cold, Nu_mid=Nu_mid,
        converged=converged, steps=step, t=t, residual=float(residual),
        params=dict(Ra=Ra, Pr=Pr, Ha=Ha, N=N, aspect=aspect, **{f"p_{k}": v_ for k, v_ in p.items()}),
    )


def centerline_extrema(res: Result):
    """Benchmark quantities: max u on the vertical centerline, max v on the horizontal centerline."""
    ny, nx = res.theta.shape
    im = (nx - 1) // 2
    jm = (ny - 1) // 2
    u_line = res.u[:, im]
    v_line = res.v[jm, :]
    ju = int(np.argmax(u_line))
    iv = int(np.argmax(v_line))
    return dict(
        u_max=float(u_line[ju]), y_at_u_max=float(res.y[ju]),
        v_max=float(v_line[iv]), x_at_v_max=float(res.x[iv]),
    )


if __name__ == "__main__":
    import time

    t0 = time.time()
    r = solve_cavity(Ra=1e4, Pr=0.71, Ha=0.0, N=41, verbose=True)
    print(f"Ra=1e4 N=41: Nu_hot={r.Nu_hot:.4f} Nu_cold={r.Nu_cold:.4f} Nu_mid={r.Nu_mid:.4f} "
          f"converged={r.converged} steps={r.steps} t={r.t:.3f}  [{time.time()-t0:.1f}s]")
    print(centerline_extrema(r))
