"""Shared interpolant of the pure-fluid (water) Nusselt function used by the similarity-reduction analyses.

A Gaussian process with an anisotropic Matern-5/2 kernel on (log10 Ra, Ha/100) fitted to ln Nu of the water runs.
It replaced a thin-plate spline, which was biased by about +1 point in E near the Ha = 0 edge of the design.
"""
import warnings
import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel


def water_interpolant(d, mask=None):
    """Returns lnN(log10Ra, Ha) fitted on the water runs of dataset d (optionally restricted by a boolean mask)."""
    base = d["scenario"] == "base"
    if mask is not None:
        base = base & mask
    co = d["coef"]
    P = np.column_stack([np.log10(co[base, 0]), co[base, 1] / 100.0])
    y = np.log(d["Nu"][base])
    _, ui = np.unique(np.round(P, 8), axis=0, return_index=True)
    kern = ConstantKernel(1.0) * Matern(length_scale=[0.5, 0.5], nu=2.5) + WhiteKernel(1e-6, (1e-10, 1e-3))
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        gp = GaussianProcessRegressor(kern, normalize_y=True, n_restarts_optimizer=3, random_state=0).fit(P[ui], y[ui])

    def lnN(lra, ha):
        X = np.column_stack([np.atleast_1d(lra).astype(float), np.atleast_1d(ha).astype(float) / 100.0])
        return gp.predict(X)
    lnN.gp = gp
    lnN.n = len(ui)
    return lnN
