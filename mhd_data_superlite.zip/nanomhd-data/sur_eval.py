"""Evaluate surrogate predictions against the solver on the held-out splits.
    python3 sur_eval.py don_data_full pidon_full ...
"""
import json, sys
import numpy as np
from sur_common import load, split

d = load()


def rel_l2(a, b):
    return np.sqrt(((a - b) ** 2).sum((1, 2)) / (b ** 2).sum((1, 2)))


def enhancement(nu, mask):
    """E = Nu_nf / Nu_water - 1 for every nanofluid case in mask, paired with the water baseline of its group.
    Replicate conditions hold one baseline ('rbase') for the whole group; main points hold one per point."""
    E = {}
    idx = np.where(mask)[0]
    base = {}
    for i in idx:
        if d["scenario"][i] == "base":
            base[d["group"][i]] = nu[i]
    for i in idx:
        if d["scenario"][i] != "base":
            E[i] = nu[i] / base[d["group"][i]] - 1
    return E


def evaluate(name):
    p = np.load(f"outputs/sur/{name}_pred.npz")
    extrap = "_ex" in name
    train, test, test_ha, test_rep = split(d, extrap=extrap)
    splits = dict(train=train, test=test, test_rep=test_rep)
    if extrap:
        splits["test_ha"] = test_ha
    out = {}
    for sname, m in splits.items():
        r = {}
        r["n"] = int(m.sum())
        for f in ("theta", "psi"):
            e = rel_l2(p[f][m], d[f][m])
            r[f"{f}_relL2_median"], r[f"{f}_relL2_p90"] = float(np.median(e)), float(np.percentile(e, 90))
        for v in ("nu_head", "nu_field"):
            e = np.abs(p[v][m] / d["Nu"][m] - 1)
            r[f"{v}_relerr_median"], r[f"{v}_relerr_p90"] = float(np.median(e)), float(np.percentile(e, 90))
        Et, Ep = enhancement(d["Nu"], m), enhancement(p["nu_head"], m)
        if Et:
            ids = sorted(Et)
            et, ep = np.array([Et[i] for i in ids]), np.array([Ep[i] for i in ids])
            r["E_mae_points"] = float(100 * np.mean(np.abs(ep - et)))
            r["E_bias_points"] = float(100 * np.mean(ep - et))
            r["E_sign_agree"] = float(np.mean((ep > 0) == (et > 0)))
            sc = d["scenario"][ids]
            for s in ("brinkman", "corcione"):
                r[f"E_mae_points_{s}"] = float(100 * np.mean(np.abs(ep - et)[sc == s]))
        out[sname] = r
    # conductivity-spread reproduction at the three held-out replicate conditions
    spread = {}
    for g in sorted(set(d["group"][test_rep])):
        mg = d["group"] == g
        Et, Ep = enhancement(d["Nu"], mg), enhancement(p["nu_head"], mg)
        for s in ("brinkman", "corcione"):
            ids = [i for i in Et if d["scenario"][i] == s]
            et, ep = np.array([Et[i] for i in ids]), np.array([Ep[i] for i in ids])
            spread[f"{g}:{s}"] = dict(K=len(ids), true_mean=float(et.mean()), pred_mean=float(ep.mean()),
                                      true_sd=float(et.std(ddof=1)), pred_sd=float(ep.std(ddof=1)),
                                      draw_corr=float(np.corrcoef(et, ep)[0, 1]),
                                      draw_rmse_points=float(100 * np.sqrt(np.mean((et - ep) ** 2))))
    out["rep_spread"] = spread
    return out


if __name__ == "__main__":
    res = {n: evaluate(n) for n in sys.argv[1:]}
    json.dump(res, open("outputs/sur/metrics.json", "w"), indent=1)
    hdr = "%-16s %-9s %4s | thetaL2 psiL2 | Nu head med/p90 %% | Nu fld med %% | E mae pts | E sign"
    print(hdr % ("model", "split", "n"))
    for n, r in res.items():
        for s in ("test", "test_ha", "test_rep"):
            if s not in r:
                continue
            q = r[s]
            print("%-16s %-9s %4d | %.3f  %.3f | %5.2f / %5.2f   | %5.2f      | %5.2f     | %.2f" % (
                n, s, q["n"], q["theta_relL2_median"], q["psi_relL2_median"], 100 * q["nu_head_relerr_median"],
                100 * q["nu_head_relerr_p90"], 100 * q["nu_field_relerr_median"], q["E_mae_points"], q["E_sign_agree"]))
