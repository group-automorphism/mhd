"""Fourier neural operator, data-only (lam = 0) and with the PDE residual loss (PINO, lam > 0).

    python3 sur_pino.py --name fno_data_full --label-frac 1.0 --lam 0
    python3 sur_pino.py --name pino_full     --label-frac 1.0 --lam 1 --n-unlab 4000

Input channels on the 41 x 41 grid: x, y and the five normalized parameters. Output channels: theta, psi,
omega. Boundary conditions that are exact in the equations are built in: theta = (1 - x) + x (1 - x) t,
psi = 256 (x (1 - x) y (1 - y))^2 s, so psi = 0 and no slip hold on all walls. The residual loss uses central
differences on the same grid in the interior. Nu comes from a head on the pooled features, because the
41-point grid recovers the wall gradient to only about 5% at Ra near 1e6.
"""
import argparse, json, pickle, time
import numpy as np
import jax, jax.numpy as jnp, optax
from sur_common import load, split, sample_params, coef_table, PR
from sur_deeponet import fit_psi_scale, IN_MU, IN_SD, init_mlp, mlp, GRID

W_, M_, L_ = 32, 12, 4
H = 1.0 / (GRID - 1)
xg = np.linspace(0, 1, GRID)
YY, XX = np.meshgrid(xg, xg, indexing="ij")           # [iy, ix]
XXj, YYj = jnp.asarray(XX, jnp.float32), jnp.asarray(YY, jnp.float32)
BCX = jnp.asarray(XX * (1 - XX), jnp.float32)
BCPSI = jnp.asarray(256 * (XX * (1 - XX) * YY * (1 - YY)) ** 2, jnp.float32)


def init(key):
    ks = jax.random.split(key, 4 + 3 * L_)
    p = dict(lift=init_mlp(ks[0], [7, W_]), proj=init_mlp(ks[1], [W_, 128, 3]),
             head=init_mlp(ks[2], [W_ + 5, 64, 1]), layers=[])
    for i in range(L_):
        sc = 1.0 / (W_ * W_)
        kr = jax.random.split(ks[4 + 3 * i], 4)
        p["layers"].append(dict(
            w1=(sc * jax.random.uniform(kr[0], (W_, W_, M_, M_)), sc * jax.random.uniform(kr[1], (W_, W_, M_, M_))),
            w2=(sc * jax.random.uniform(kr[2], (W_, W_, M_, M_)), sc * jax.random.uniform(kr[3], (W_, W_, M_, M_))),
            skip=init_mlp(ks[5 + 3 * i], [W_, W_])))
    return p


def spectral(layer, x):               # x: (B, W, ny, nx)
    xf = jnp.fft.rfft2(x)
    w1 = layer["w1"][0] + 1j * layer["w1"][1]
    w2 = layer["w2"][0] + 1j * layer["w2"][1]
    out = jnp.zeros((x.shape[0], W_, x.shape[2], x.shape[3] // 2 + 1), jnp.complex64)
    out = out.at[:, :, :M_, :M_].set(jnp.einsum("bixy,ioxy->boxy", xf[:, :, :M_, :M_], w1))
    out = out.at[:, :, -M_:, :M_].set(jnp.einsum("bixy,ioxy->boxy", xf[:, :, -M_:, :M_], w2))
    return jnp.fft.irfft2(out, s=x.shape[2:])


def forward(params, Xn, psis):
    """Xn (B,5) normalized parameters, psis (B,) -> theta, psi, omega each (B, 41, 41), plus log Nu (B,)."""
    B = Xn.shape[0]
    pc = jnp.broadcast_to(Xn[:, :, None, None], (B, 5, GRID, GRID))
    g = jnp.concatenate([jnp.broadcast_to(XXj, (B, 1, GRID, GRID)), jnp.broadcast_to(YYj, (B, 1, GRID, GRID)), pc], 1)
    x = jnp.einsum("bcyx,cw->bwyx", g, params["lift"][0][0]) + params["lift"][0][1][None, :, None, None]
    for lay in params["layers"]:
        sk = jnp.einsum("bwyx,wv->bvyx", x, lay["skip"][0][0]) + lay["skip"][0][1][None, :, None, None]
        x = jax.nn.gelu(spectral(lay, x) + sk)
    feat = x
    h = jnp.transpose(feat, (0, 2, 3, 1))
    for Wm, b in params["proj"][:-1]:
        h = jax.nn.gelu(h @ Wm + b)
    Wm, b = params["proj"][-1]
    o = h @ Wm + b                                              # (B, ny, nx, 3)
    th = (1 - XXj) + BCX * o[..., 0]
    ps = psis[:, None, None] * BCPSI * o[..., 1]
    om = 20.0 * psis[:, None, None] * o[..., 2]
    pooled = jnp.concatenate([feat.mean((2, 3)), Xn], 1)
    lognu = mlp(params["head"], pooled)[:, 0]
    return th, ps, om, lognu


def fd_loss(th, ps, om, coef):
    dx = lambda f: (f[:, 1:-1, 2:] - f[:, 1:-1, :-2]) / (2 * H)
    dy = lambda f: (f[:, 2:, 1:-1] - f[:, :-2, 1:-1]) / (2 * H)
    lap = lambda f: (f[:, 1:-1, 2:] + f[:, 1:-1, :-2] + f[:, 2:, 1:-1] + f[:, :-2, 1:-1] - 4 * f[:, 1:-1, 1:-1]) / H**2
    dxx = lambda f: (f[:, 1:-1, 2:] - 2 * f[:, 1:-1, 1:-1] + f[:, 1:-1, :-2]) / H**2
    c = lambda j: coef[:, j][:, None, None]
    Ra, Ha, k, rcp, mu, rho, rb, sg = (c(j) for j in range(8))
    u, v = dy(ps), -dx(ps)
    a_T, d_T = u * dx(th) + v * dy(th), (k / rcp) * lap(th)
    a_W, d_W = u * dx(om) + v * dy(om), PR * (mu / rho) * lap(om)
    b_W, l_W = Ra * PR * (rb / rho) * dx(th), Ha**2 * PR * (sg / rho) * dxx(ps)
    omi = om[:, 1:-1, 1:-1]
    terms = [(a_T - d_T, jnp.abs(a_T) + jnp.abs(d_T)),
             (a_W - d_W - b_W - l_W, jnp.abs(a_W) + jnp.abs(d_W) + jnp.abs(b_W) + jnp.abs(l_W)),
             (lap(ps) + omi, jnp.abs(lap(ps)) + jnp.abs(omi))]
    out = 0.0
    for r, s in terms:
        s = jax.lax.stop_gradient(jnp.mean(s, axis=(1, 2), keepdims=True)) + 1e-3
        out += jnp.mean((r / s) ** 2)
    adiab = jnp.mean(((th[:, 1, :] - th[:, 0, :]) / H) ** 2) + jnp.mean(((th[:, -1, :] - th[:, -2, :]) / H) ** 2)
    return out, adiab


def loss_fn(params, lab, unlab, lam, w):
    th, ps, om, ln = forward(params, lab["Xn"], lab["psis"])
    l_th = jnp.mean((th - lab["theta"]) ** 2)
    l_ps = jnp.mean((ps / lab["psis"][:, None, None] - lab["psi"]) ** 2)
    l_nu = jnp.mean((ln - lab["lognu"]) ** 2)
    data = w["th"] * l_th + w["ps"] * l_ps + w["nu"] * l_nu
    phys = ad = 0.0
    if lam > 0:
        phys, ad = fd_loss(th, ps, om, lab["coef"])
        if unlab is not None:
            tu, pu, ou, _ = forward(params, unlab["Xn"], unlab["psis"])
            p2, a2 = fd_loss(tu, pu, ou, unlab["coef"])
            phys, ad = 0.5 * (phys + p2), 0.5 * (ad + a2)
    return data + lam * (phys + ad), dict(th=l_th, ps=l_ps, nu=l_nu, phys=phys, bc=ad)


def predict(params, X, coef, psis, chunk=32):
    Xn = (X - IN_MU) / IN_SD
    outs = dict(theta=[], psi=[], nu_head=[])
    for i in range(0, len(X), chunk):
        sl = slice(i, i + chunk)
        th, ps, om, ln = forward(params, jnp.asarray(Xn[sl], jnp.float32), jnp.asarray(psis[sl], jnp.float32))
        outs["theta"].append(np.asarray(th)); outs["psi"].append(np.asarray(ps)); outs["nu_head"].append(np.exp(np.asarray(ln)))
    r = {k: np.concatenate(v) for k, v in outs.items()}
    r["nu_field"] = r["nu_head"].copy()   # no separate field-based estimate for the FNO
    return r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--label-frac", type=float, default=1.0)
    ap.add_argument("--lam", type=float, default=0.0)
    ap.add_argument("--n-unlab", type=int, default=0)
    ap.add_argument("--steps", type=int, default=6000)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--extrap", action="store_true", help="train on Ha <= 70 only")
    args = ap.parse_args()

    d = load()
    train, test, test_ha, test_rep = split(d, extrap=args.extrap)
    rng = np.random.default_rng(args.seed)
    tr_idx = np.where(train)[0]
    if args.label_frac < 1.0:
        groups = np.unique(d["group"][tr_idx]); rng.shuffle(groups)
        keep = set(groups[: max(1, int(round(args.label_frac * len(groups))))])
        tr_idx = np.array([i for i in tr_idx if d["group"][i] in keep])
    print(f"{args.name}: {len(tr_idx)} labeled cases, lam={args.lam}, unlabeled rows {args.n_unlab}", flush=True)
    psi_fn, psi_resid = fit_psi_scale(d["X"][train], d["psi"][train])
    psis_all = psi_fn(d["X"])
    # theta target is the full field; the network predicts theta directly (hard BCs already inside forward)
    tn = lambda i: dict(
        Xn=jnp.asarray((d["X"][i] - IN_MU) / IN_SD, jnp.float32), coef=jnp.asarray(d["coef"][i], jnp.float32),
        psis=jnp.asarray(psis_all[i], jnp.float32), theta=jnp.asarray(d["theta"][i], jnp.float32),
        psi=jnp.asarray(d["psi"][i] / psis_all[i][:, None, None], jnp.float32),
        lognu=jnp.asarray(np.log(d["Nu"][i]), jnp.float32))
    if args.n_unlab > 0:
        Xu = sample_params(args.n_unlab, seed=args.seed + 100)
        Cu, Su = coef_table(Xu), psi_fn(Xu)

    w = dict(th=100.0, ps=100.0, nu=100.0)
    params = init(jax.random.PRNGKey(args.seed))
    sched = optax.cosine_decay_schedule(args.lr, args.steps, alpha=0.01)
    opt = optax.chain(optax.clip_by_global_norm(5.0), optax.adam(sched))
    state = opt.init(params)

    @jax.jit
    def step(params, state, lab, unlab):
        (l, aux), g = jax.value_and_grad(loss_fn, has_aux=True)(params, lab, unlab, args.lam, w)
        up, state = opt.update(g, state, params)
        return optax.apply_updates(params, up), state, l, aux

    t0 = time.time(); hist = []
    for it in range(args.steps):
        b = rng.choice(tr_idx, size=min(args.batch, len(tr_idx)), replace=False)
        unlab = None
        if args.lam > 0 and args.n_unlab > 0:
            j = rng.choice(len(Xu), size=args.batch, replace=False)
            unlab = dict(Xn=jnp.asarray((Xu[j] - IN_MU) / IN_SD, jnp.float32), coef=jnp.asarray(Cu[j], jnp.float32),
                         psis=jnp.asarray(Su[j], jnp.float32))
        params, state, l, aux = step(params, state, tn(b), unlab)
        if it % 250 == 0 or it == args.steps - 1:
            a = {k: float(v) for k, v in aux.items()}
            hist.append(dict(it=it, loss=float(l), t=round(time.time() - t0), **a))
            print(f"{it:5d} loss {float(l):.4f} th {a['th']:.2e} ps {a['ps']:.2e} nu {a['nu']:.2e} "
                  f"phys {a['phys']:.2e} bc {a['bc']:.2e}  {time.time() - t0:.0f}s", flush=True)
    t1 = time.time()
    pred = predict(params, d["X"], d["coef"], psis_all)
    infer = time.time() - t1
    np.savez_compressed(f"outputs/sur/{args.name}_pred.npz", **pred)
    pickle.dump(jax.tree_util.tree_map(np.asarray, params), open(f"outputs/sur/{args.name}_params.pkl", "wb"))
    json.dump(dict(args=vars(args), hist=hist, train_seconds=time.time() - t0, infer_seconds_all=infer,
                   n_cases=len(d["X"])), open(f"outputs/sur/{args.name}_log.json", "w"))
    print("done", flush=True)


if __name__ == "__main__":
    main()
