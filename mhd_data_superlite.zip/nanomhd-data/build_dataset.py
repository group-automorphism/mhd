"""Collect all ensemble cases into one array file for surrogate training.

Inputs per case: log10 Ra, Ha, phi, k*, mu* (nanofluid ratios actually used by the solver).
Outputs: theta, psi on the common 41 x 41 grid (index [iy, ix]) and the wall Nusselt number.
Groups: cases of one design point share a group id so splits never separate a nanofluid run
from its water baseline.
"""
import csv, glob, json, os, numpy as np
from properties import nanofluid_ratios

SOURCES = [  # (design csv, run dir, group prefix, kind)
    ("outputs/design_scen_128.csv", "outputs/ensemble_scen", "S", "main"),
    ("outputs/design_rep.csv", "outputs/ensemble_rep", "R1e5_30", "rep"),
] + [(f"outputs/rep_grid/design_Ra{Ra}_Ha{Ha}.csv", f"outputs/rep_grid/Ra{Ra}_Ha{Ha}", f"R{Ra}_{Ha}", "rep")
     for Ra in ("1e4", "1e5", "1e6") for Ha in ("0", "60")]

X, TH, PS, NU, G, KIND, SC, CID = [], [], [], [], [], [], [], []
for des, d, pre, kind in SOURCES:
    res = {}
    for l in open(f"{d}/results.jsonl"):
        r = json.loads(l)
        if "converged" in r:
            res[r["case_id"]] = r
    for r in csv.DictReader(open(des)):
        cid = r["case_id"]
        z = np.load(f"{d}/{cid}.npz")
        p = nanofluid_ratios(float(r["phi"]), mu_model=r["mu_model"], k_scale=float(r["k_scale"]),
                             mu_scale=float(r["mu_scale"]))
        X.append([np.log10(float(r["Ra"])), float(r["Ha"]), float(r["phi"]), p["k"], p["mu"]])
        TH.append(z["theta"]); PS.append(z["psi"]); NU.append(float(z["Nu_hot"]))
        G.append(f"{pre}:{r['point_id']}" if kind == "main" else f"{pre}"); KIND.append(kind)
        SC.append(r["scenario"]); CID.append(f"{pre}:{cid}")
np.savez_compressed("outputs/surrogate_data.npz", X=np.array(X), theta=np.array(TH), psi=np.array(PS),
                    Nu=np.array(NU), group=np.array(G), kind=np.array(KIND), scenario=np.array(SC),
                    case=np.array(CID))
print(len(X), "cases;", len(set(G)), "groups; X range", np.array(X).min(0).round(3), np.array(X).max(0).round(3))
print("psi range", np.array(PS).min(), np.array(PS).max(), " theta range", np.array(TH).min(), np.array(TH).max())
