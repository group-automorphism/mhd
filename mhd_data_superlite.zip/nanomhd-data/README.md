# NanoMHD (lite): simulations and code for nanofluid MHD convection under property uncertainty

Repository: https://github.com/group-automorphism/mhd

Data and code for: F. Kamalov, "Nanofluid magnetohydrodynamic convection under property uncertainty: an exact
similarity reduction", submitted to the International Journal of Ambient Energy.

Problem: steady laminar natural convection of an Al2O3-water nanofluid in a differentially heated square cavity
under a horizontal magnetic field. Single-phase Boussinesq model, streamfunction-vorticity form. Water Pr = 6.07,
10^4 <= Ra <= 10^6, 0 <= Ha <= 100, 1% <= phi <= 6%.

## This lite version

This version omits the temperature and stream-function fields, the trained surrogate models, and two alternative
conductivity posteriors. `outputs/runs.csv` lists every run with its inputs and hot-wall Nusselt number, which is
enough to reproduce the theory checks, the Gaussian-process baseline, and the tables. Retraining the neural-operator
surrogates and redrawing the field figure need the full dataset `outputs/surrogate_data.npz`, available in the
full release of the repository.

## Contents

| Path | Content |
|---|---|
| `outputs/runs.csv` | One row per run: case, group, kind, scenario, log10 Ra, Ha, phi, k*, mu*, Nu. The full release adds `outputs/surrogate_data.npz` with the fields. |
| `outputs/surrogate_data.npz` (full release only) | All 583 simulation runs. Keys: `X` inputs (log10 Ra, Ha, phi, k*, mu*), `theta` and `psi` fields on a 41 x 41 grid indexed [y, x], `Nu` hot-wall Nusselt number from the native grid, `group` design point or replicate block, `scenario` (base = water, brinkman, corcione), `case` run identifier, `kind` (main or rep). |
| `outputs/design_scen_128.csv`, `outputs/design_rep.csv`, `outputs/rep_grid/design_*.csv` | Run designs: Sobol design (128 points x 3 runs) and replicate blocks, with the sampled conductivity draws. |
| `outputs/**/results.jsonl` | Per-run solver log: Nu, convergence flag, grid size, run time, energy imbalance. |
| `outputs/post_k.npz` | Posterior draws of the hierarchical conductivity model (15-45 C filter); The full release adds posteriors with no temperature filter and with 20-35 C. |
| `outputs/validation_log.txt`, `outputs/validation_results_gitt.json`, `benchmarks/gitt_mhd_cavity.csv` | Solver verification results and the literature reference values. |
| `outputs/theory_*.npz`, `outputs/theory_elasticity.npy` | Similarity-reduction checks. |
| `outputs/gp_baseline.json` | Gaussian-process baseline metrics. |
| `gpu_results/outputs/maps.npz` | Probability maps of enhancement and break-even viscosities from the FNO surrogates. |
| `gpu_results/outputs/spot_checks.csv` | Twelve additional solver runs between the two viscosity closures. |
| `gpu_results/outputs/sur/` | Surrogate metrics for 36 trained models, and training logs; trained parameters are in the full release. |
| `*.py` | Solver, verification, calibration, ensemble, surrogate training and evaluation, theory checks, figures and tables. |
| `gpu_package/` | Scripts used to train the surrogates on a GPU. |

## Not included

The conductivity measurements are third-party data from the supplementary material of J. Tielke et al.,
"Statistical analysis of thermal conductivity experimentally measured in water-based nanofluids",
Proc. R. Soc. A 477 (2021), doi:10.1098/rspa.2021.0222 (file `rspa20210222_si_005.csv`). To reproduce the
calibration, download that file and run

    python3 prepare_tielke.py rspa20210222_si_005.csv outputs/conductivity_water.csv
    python3 calibrate.py fit --csv outputs/conductivity_water.csv --property k --material Al2O3 --T-range 15 45 --out outputs/post_k.npz

## Reproducing results

Python 3.10 or newer with numpy, scipy, matplotlib and scikit-learn; JAX and optax for the surrogates.

    python3 validate.py                 # solver verification
    python3 theory_check.py             # similarity reduction against the simulations
    python3 theory_breakeven.py         # break-even viscosity
    python3 theory_maps.py              # probability maps from the reduction
    python3 gp_baseline.py              # Gaussian-process baseline
    python3 gen_tables.py               # tables
    python3 make_paper_figs.py          # figures (needs outputs/conductivity_water.csv for the first figure)

New simulations: `python3 ensemble.py scenarios ...` and `python3 ensemble.py run ...` (see the docstring).

## License

Code: MIT License. Data: Creative Commons Attribution 4.0 International (CC BY 4.0).
