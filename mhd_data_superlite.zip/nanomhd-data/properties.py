"""Nanofluid property ratios for the single-phase MHD natural-convection solver.

All functions return ratios relative to the base fluid, which is the form the
nondimensional equations need. Multiplicative uncertainty hooks (k_scale,
mu_scale, sigma_scale) are included so the same code can later be driven by
posterior samples of the property models.

Coefficients below are textbook values or recalled from the original papers.
Verify the Corcione viscosity coefficients and the material constants against
your preferred sources before quoting numbers in a manuscript.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Material:
    rho: float      # density, kg/m^3
    cp: float       # specific heat, J/(kg K)
    k: float        # thermal conductivity, W/(m K)
    beta: float     # thermal expansion coefficient, 1/K
    sigma: float    # electrical conductivity, S/m
    mu: float = float("nan")  # dynamic viscosity, Pa s (base fluid only)

    @property
    def Pr(self) -> float:
        return self.mu * self.cp / self.k


# Typical values near 300 K. Water sigma = 0.05 S/m follows common MHD cavity papers.
WATER = Material(rho=997.1, cp=4179.0, k=0.613, beta=2.1e-4, sigma=0.05, mu=8.91e-4)
AL2O3 = Material(rho=3970.0, cp=765.0, k=40.0, beta=0.85e-5, sigma=1e-10)


def pure_fluid() -> dict:
    """Unit property ratios (phi = 0)."""
    return dict(rho=1.0, rcp=1.0, rbeta=1.0, k=1.0, mu=1.0, sigma=1.0)


def k_maxwell(phi: float, kp: float, kf: float) -> float:
    """Maxwell effective-medium conductivity ratio for spherical particles."""
    num = kp + 2.0 * kf + 2.0 * phi * (kp - kf)
    den = kp + 2.0 * kf - phi * (kp - kf)
    return num / den


def sigma_maxwell(phi: float, sp: float, sf: float) -> float:
    """Maxwell electrical conductivity ratio."""
    r = sp / sf
    return 1.0 + 3.0 * (r - 1.0) * phi / ((r + 2.0) - (r - 1.0) * phi)


def mu_brinkman(phi: float) -> float:
    return 1.0 / (1.0 - phi) ** 2.5


def mu_einstein(phi: float) -> float:
    return 1.0 + 2.5 * phi


def mu_corcione(phi: float, d_p: float, d_f: float = 0.385e-9) -> float:
    """Corcione (2011) correlation, mu_nf/mu_f = 1 / (1 - 34.87 (d_p/d_f)^-0.3 phi^1.03).

    d_p: particle diameter in meters. d_f: equivalent base-fluid molecule
    diameter in meters (0.385 nm for water as commonly quoted).
    """
    return 1.0 / (1.0 - 34.87 * (d_p / d_f) ** (-0.3) * phi ** 1.03)


def nanofluid_ratios(
    phi: float,
    base: Material = WATER,
    particle: Material = AL2O3,
    k_model: str = "maxwell",
    mu_model: str = "brinkman",
    d_p: float = 33e-9,
    k_scale: float = 1.0,
    mu_scale: float = 1.0,
    sigma_scale: float = 1.0,
) -> dict:
    """Return property ratios nanofluid/base fluid.

    Keys: rho, rcp ((rho cp) ratio), rbeta ((rho beta) ratio), k, mu, sigma.

    The *_scale arguments multiply the enhancement above the base fluid, e.g.
    k = 1 + k_scale * (k_model - 1). They are the hooks for uncertainty
    propagation: k_scale = 1 reproduces the chosen closure exactly.
    """
    if not 0.0 <= phi < 0.5:
        raise ValueError("phi must be in [0, 0.5)")

    rho = (1 - phi) + phi * particle.rho / base.rho
    rcp = (1 - phi) + phi * (particle.rho * particle.cp) / (base.rho * base.cp)
    rbeta = (1 - phi) + phi * (particle.rho * particle.beta) / (base.rho * base.beta)

    if k_model == "maxwell":
        k_ratio = k_maxwell(phi, particle.k, base.k)
    else:
        raise ValueError(f"unknown k_model {k_model!r}")

    if mu_model == "brinkman":
        mu_ratio = mu_brinkman(phi)
    elif mu_model == "einstein":
        mu_ratio = mu_einstein(phi)
    elif mu_model == "corcione":
        mu_ratio = mu_corcione(phi, d_p)
    else:
        raise ValueError(f"unknown mu_model {mu_model!r}")

    sigma_ratio = sigma_maxwell(phi, particle.sigma, base.sigma)

    return dict(
        rho=rho,
        rcp=rcp,
        rbeta=rbeta,
        k=1.0 + k_scale * (k_ratio - 1.0),
        mu=1.0 + mu_scale * (mu_ratio - 1.0),
        sigma=1.0 + sigma_scale * (sigma_ratio - 1.0),
    )


if __name__ == "__main__":
    for phi in (0.0, 0.02, 0.04, 0.06):
        r = nanofluid_ratios(phi)
        rc = nanofluid_ratios(phi, mu_model="corcione")
        print(
            f"phi={phi:4.2f}  k*={r['k']:.4f}  mu*(Brinkman)={r['mu']:.4f}  "
            f"mu*(Corcione)={rc['mu']:.4f}  rho*={r['rho']:.4f}  "
            f"rcp*={r['rcp']:.4f}  rbeta*={r['rbeta']:.4f}  sigma*={r['sigma']:.4f}"
        )
    print(f"water Pr = {WATER.Pr:.3f}")
