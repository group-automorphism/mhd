"""Uncertainty maps from trained FNO surrogates (one model per seed; their spread is reported as surrogate error).

For Ra in {1e4, 1e5, 1e6}, a grid of Ha and phi, and K posterior conductivity draws (the same underlying draws at
every grid cell), compute the enhancement E = Nu_nf / Nu_water - 1 under each viscosity closure, and the
break-even viscosity ratio mu*_0 at which E = 0 for the 5th, 50th and 95th percentile conductivity draw.

    python sur_maps.py --models fno_full_s0 fno_full_s1 fno_full_s2 --K 400
Writes outputs/maps.npz.
"""
import argparse, pickle, time
import numpy as np
import jax, jax.numpy as jnp
from sur_common import load, split
from sur_deeponet import fit_psi_scale, IN_MU, IN_SD
from sur_pino import forward
from properties import nanofluid_ratios
from calibrate import Posterior, property_draws

MU_GRID = np.linspace(1.0, 2.0, 41)   # training data span mu* from 1.0 to 2.01


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", nargs="+", required=True)
    ap.add_argument("--K", type=int, default=400)
    ap.add_argument("--nHa", type=int, default=26)
    ap.add_argument("--nphi", type=int, default=11)
    ap.add_argument("--batch", type=int, default=1024)
    ap.add_argument("--out", default="outputs/maps.npz")
    args = ap.parse_args()

    d = load()
    train, _, _, _ = split(d, extrap=False)
    psi_fn, _ = fit_psi_scale(d["X"][train], d["psi"][train])
    nets = [jax.tree_util.tree_map(jnp.asarray, pickle.load(open(f"outputs/sur/{m}_params.pkl", "rb")))
            for m in args.models]
    nu_jit = jax.jit(lambda p, Xn, ps: jnp.exp(forward(p, Xn, ps)[3]))

    def nu(X):
        """Nu for every row of X under every model -> (n_models, n_rows)."""
        X = np.asarray(X, np.float32)
        n = len(X); B = args.batch
        pad = (-n) % B
        Xp = np.concatenate([X, np.repeat(X[:1], pad, 0)]) if pad else X
        Xn = (Xp - IN_MU) / IN_SD
        ps = psi_fn(Xp)
        out = np.empty((len(nets), len(Xp)), np.float64)
        for j, p in enumerate(nets):
            for i in range(0, len(Xp), B):
                out[j, i:i + B] = np.asarray(nu_jit(p, jnp.asarray(Xn[i:i + B]), jnp.asarray(ps[i:i + B])))
        return out[:, :n]

    post = Posterior.load("outputs/post_k.npz", "k")
    Ras = np.array([1e4, 1e5, 1e6]); Has = np.linspace(0, 100, args.nHa); phis = np.linspace(0.01, 0.06, args.nphi)
    closures = ("brinkman", "corcione")
    kdraw = np.empty((len(phis), args.K))
    for f, phi in enumerate(phis):   # same rng seed at every phi, so draw j is the same "laboratory" everywhere
        kdraw[f] = property_draws(post, float(phi), args.K, np.random.default_rng(2024))[0]
    mu_cl = {c: np.array([nanofluid_ratios(float(p), mu_model=c)["mu"] for p in phis]) for c in closures}
    M = len(nets)
    shape = (len(Ras), len(Has), len(phis))
    E_mean = {c: np.empty(shape + (M,)) for c in closures}
    E_q = {c: np.empty(shape + (3, M)) for c in closures}
    P_pos = {c: np.empty(shape + (M,)) for c in closures}
    k_q = np.percentile(kdraw, [5, 50, 95], axis=1).T            # (nphi, 3)
    mu_be = np.full(shape + (3, M), np.nan)                       # break-even mu* (nan: outside [1, 2])
    mu_be_flag = np.zeros(shape + (3, M), int)                    # -1: E<0 already at mu*=1, +1: E>0 at mu*=2
    t0 = time.time()
    for r, Ra in enumerate(Ras):
        for h, Ha in enumerate(Has):
            base = nu(np.array([[np.log10(Ra), Ha, 0.0, 1.0, 1.0]]))[:, 0]           # (M,)
            for c in closures:
                rows = np.concatenate([np.column_stack([np.full(args.K, np.log10(Ra)), np.full(args.K, Ha),
                                                        np.full(args.K, phi), kdraw[f], np.full(args.K, mu_cl[c][f])])
                                       for f, phi in enumerate(phis)])
                E = nu(rows).reshape(M, len(phis), args.K) / base[:, None, None] - 1
                E_mean[c][r, h] = E.mean(2).T
                E_q[c][r, h] = np.percentile(E, [5, 50, 95], axis=2).transpose(2, 0, 1)   # (nphi, 3, M)
                P_pos[c][r, h] = (E > 0).mean(2).T
            rows = np.array([[np.log10(Ra), Ha, phi, k_q[f, q], mu] for f, phi in enumerate(phis)
                             for q in range(3) for mu in MU_GRID])
            E = (nu(rows).reshape(M, len(phis), 3, len(MU_GRID)) / base[:, None, None, None] - 1)
            for f in range(len(phis)):
                for q in range(3):
                    for j in range(M):
                        e = E[j, f, q]
                        if e[0] <= 0:
                            mu_be_flag[r, h, f, q, j] = -1
                        elif e[-1] > 0:
                            mu_be_flag[r, h, f, q, j] = 1
                        else:
                            i = int(np.argmax(e <= 0))
                            mu_be[r, h, f, q, j] = MU_GRID[i - 1] + (MU_GRID[i] - MU_GRID[i - 1]) * e[i - 1] / (e[i - 1] - e[i])
        print(f"Ra={Ra:.0e} done, {time.time() - t0:.0f}s", flush=True)
    np.savez_compressed(args.out, Ra=Ras, Ha=Has, phi=phis, K=args.K, models=np.array(args.models), k_q=k_q,
                        mu_brinkman=mu_cl["brinkman"], mu_corcione=mu_cl["corcione"], mu_grid=MU_GRID,
                        mu_be=mu_be, mu_be_flag=mu_be_flag,
                        **{f"E_mean_{c}": E_mean[c] for c in closures}, **{f"E_q_{c}": E_q[c] for c in closures},
                        **{f"P_pos_{c}": P_pos[c] for c in closures})
    print("wrote", args.out)


if __name__ == "__main__":
    main()
