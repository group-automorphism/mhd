"""Design and run the property-uncertainty ensemble.

    python3 ensemble.py design --n 256 --post-k outputs/post_k.npz --post-mu outputs/post_mu.npz --out outputs/design.csv
    python3 ensemble.py run --design outputs/design.csv --out outputs/ensemble --workers 2

design: scrambled Sobol sequence over (log10 Ra, Ha, phi), and for each point one posterior draw of
        the conductivity and viscosity curves for a "new laboratory" (calibrate.property_draws).
run:    one solver call per row with checkpointing (finished cases are skipped), fields saved on a
        common 41 x 41 grid so cases of different native resolution can be stacked for training.

Fixed here: base fluid water (Pr from properties.WATER), Al2O3, Maxwell electrical conductivity,
horizontal field. Ranges are the defaults below; change them on the command line.
"""
from __future__ import annotations

import argparse
import csv
import json
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
from scipy.interpolate import RegularGridInterpolator
from scipy.stats import qmc

from calibrate import Posterior, property_draws
from properties import WATER, nanofluid_ratios
from solver import solve_cavity

GRID = 41  # common output grid


def choose_N(Ra: float, Ha: float) -> int:
    """Resolution rule from the validation runs: boundary layers (Ra) and Hartmann layers (~1/Ha)."""
    N = 81
    if Ra > 1e5 or Ha >= 40:
        N = 101
    if Ra > 3e5 or Ha >= 60:
        N = 121
    if Ra >= 5e5 or Ha >= 90:
        N = 161
    return N


def load_post(path: str, prop: str) -> Posterior:
    return Posterior.load(path, prop)


def design(args):
    rng = np.random.default_rng(args.seed)
    post_k = load_post(args.post_k, "k")
    post_mu = load_post(args.post_mu, "mu")
    n = args.n
    if n & (n - 1):
        print(f"note: n={n} is not a power of two; Sobol balance is best for powers of two")
    u = qmc.Sobol(d=3, scramble=True, seed=args.seed).random(n)
    logRa = args.logRa[0] + u[:, 0] * (args.logRa[1] - args.logRa[0])
    Ha = args.Ha[0] + u[:, 1] * (args.Ha[1] - args.Ha[0])
    phi = args.phi[0] + u[:, 2] * (args.phi[1] - args.phi[0])
    rows = []
    for i in range(n):
        k_ratio, k_scale = property_draws(post_k, phi[i], 1, rng)
        mu_ratio, mu_scale = property_draws(post_mu, phi[i], 1, rng)
        Ra = 10 ** logRa[i]
        rows.append(dict(
            case_id=f"c{i:04d}", Ra=f"{Ra:.6g}", Ha=f"{Ha[i]:.4f}", phi=f"{phi[i]:.5f}",
            k_ratio=f"{k_ratio[0]:.5f}", mu_ratio=f"{mu_ratio[0]:.5f}",
            k_scale=f"{k_scale[0]:.5f}", mu_scale=f"{mu_scale[0]:.5f}", N=choose_N(Ra, Ha[i]),
        ))
    with open(args.out, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    cost = sum((int(r["N"]) / 81) ** 3 for r in rows)
    print(f"wrote {n} cases to {args.out} (relative cost {cost:.0f} x an N=81 run)")


SCENARIOS = ("base", "brinkman", "corcione")


def _scenario_rows(point_id, Ra, Ha, phi, k_scale, k_ratio):
    """Three paired runs: pure-water baseline, then the nanofluid under each viscosity closure.
    The two nanofluid runs share the same sampled conductivity curve."""
    rows = []
    for sc in SCENARIOS:
        is_base = sc == "base"
        rows.append(dict(
            case_id=f"{point_id}_{sc}", point_id=point_id, scenario=sc,
            Ra=f"{Ra:.6g}", Ha=f"{Ha:.4f}", phi=f"{0.0 if is_base else phi:.5f}",
            k_ratio=f"{1.0 if is_base else k_ratio:.5f}", k_scale=f"{1.0 if is_base else k_scale:.5f}",
            mu_model="brinkman" if is_base else sc, mu_scale="1.0", N=choose_N(Ra, Ha),
        ))
    return rows


def _write(rows, path):
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    cost = sum((int(r["N"]) / 81) ** 3 for r in rows)
    print(f"wrote {len(rows)} cases to {path} (relative cost {cost:.0f} x an N=81 run)")


def design_scenarios(args):
    """Sobol design over (log10 Ra, Ha, phi), one conductivity draw per point, three paired runs each."""
    rng = np.random.default_rng(args.seed)
    post_k = load_post(args.post_k, "k")
    n = args.n
    if n & (n - 1):
        print(f"note: n={n} is not a power of two; Sobol balance is best for powers of two")
    u = qmc.Sobol(d=3, scramble=True, seed=args.seed).random(n)
    rows = []
    for i in range(n):
        Ra = 10 ** (args.logRa[0] + u[i, 0] * (args.logRa[1] - args.logRa[0]))
        Ha = args.Ha[0] + u[i, 1] * (args.Ha[1] - args.Ha[0])
        phi = args.phi[0] + u[i, 2] * (args.phi[1] - args.phi[0])
        k_ratio, k_scale = property_draws(post_k, phi, 1, rng)
        rows += _scenario_rows(f"p{i:03d}", Ra, Ha, phi, k_scale[0], k_ratio[0])
    _write(rows, args.out)


def design_replicates(args):
    """K conductivity draws at one fixed condition, each run under both viscosity closures."""
    rng = np.random.default_rng(args.seed)
    post_k = load_post(args.post_k, "k")
    k_ratio, k_scale = property_draws(post_k, args.phi, args.K, rng)
    rows = []
    for j in range(args.K):
        rows += [r for r in _scenario_rows(f"r{j:02d}", args.Ra, args.Ha, args.phi, k_scale[j], k_ratio[j])
                 if r["scenario"] != "base"]
    rows += [r for r in _scenario_rows("rbase", args.Ra, args.Ha, args.phi, 1.0, 1.0) if r["scenario"] == "base"]
    _write(rows, args.out)


def _resample(res):
    xg = np.linspace(0, 1, GRID)
    yg = np.linspace(0, 1, GRID)
    Y, X = np.meshgrid(yg, xg, indexing="ij")
    pts = np.stack([Y.ravel(), X.ravel()], axis=-1)
    out = {}
    for name in ("theta", "psi", "u", "v"):
        f = RegularGridInterpolator((res.y, res.x), getattr(res, name), method="linear")
        out[name] = f(pts).reshape(GRID, GRID)
    return out


def run_one(job):
    row, outdir = job
    path = Path(outdir) / f"{row['case_id']}.npz"
    if path.exists():
        return dict(case_id=row["case_id"], skipped=True)
    t0 = time.time()
    props = nanofluid_ratios(
        float(row["phi"]),
        mu_model=row.get("mu_model") or "brinkman",
        k_scale=float(row["k_scale"]),
        mu_scale=float(row.get("mu_scale") or 1.0),
    )
    try:
        res = solve_cavity(Ra=float(row["Ra"]), Pr=WATER.Pr, Ha=float(row["Ha"]), props=props, N=int(row["N"]))
    except FloatingPointError as exc:
        return dict(case_id=row["case_id"], failed=str(exc))
    fields = _resample(res)
    np.savez_compressed(
        path, **fields, Nu_hot=res.Nu_hot, Nu_cold=res.Nu_cold, Nu_mid=res.Nu_mid,
        converged=res.converged, residual=res.residual,
    )
    return dict(
        case_id=row["case_id"], point_id=row.get("point_id"), scenario=row.get("scenario"),
        Nu_hot=res.Nu_hot, Nu_mid=res.Nu_mid, converged=bool(res.converged),
        N=int(row["N"]), seconds=round(time.time() - t0, 1),
        energy_imbalance=abs(res.Nu_mid - res.Nu_hot) / res.Nu_hot,
    )


def run(args):
    outdir = Path(args.out)
    outdir.mkdir(parents=True, exist_ok=True)
    with open(args.design, newline="") as fh:
        rows = list(csv.DictReader(fh))
    jobs = [(r, str(outdir)) for r in rows]
    log = outdir / "results.jsonl"
    done = fail = 0
    t0 = time.time()
    with Pool(args.workers) as pool, open(log, "a") as fh:
        for r in pool.imap_unordered(run_one, jobs):
            fh.write(json.dumps(r) + "\n")
            fh.flush()
            done += 1
            fail += "failed" in r or r.get("converged") is False
            if done % 5 == 0 or done == len(jobs):
                print(f"{done}/{len(jobs)} cases, {fail} problems, {time.time() - t0:.0f}s", flush=True)
    print(f"finished; per-case log in {log}")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("design")
    d.add_argument("--n", type=int, required=True)
    d.add_argument("--post-k", required=True)
    d.add_argument("--post-mu", required=True)
    d.add_argument("--out", required=True)
    d.add_argument("--seed", type=int, default=0)
    d.add_argument("--logRa", type=float, nargs=2, default=[4.0, 6.0])
    d.add_argument("--Ha", type=float, nargs=2, default=[0.0, 100.0])
    d.add_argument("--phi", type=float, nargs=2, default=[0.0, 0.06])
    sc = sub.add_parser("scenarios", help="paired baseline/Brinkman/Corcione design with calibrated conductivity")
    sc.add_argument("--n", type=int, required=True)
    sc.add_argument("--post-k", required=True)
    sc.add_argument("--out", required=True)
    sc.add_argument("--seed", type=int, default=0)
    sc.add_argument("--logRa", type=float, nargs=2, default=[4.0, 6.0])
    sc.add_argument("--Ha", type=float, nargs=2, default=[0.0, 100.0])
    sc.add_argument("--phi", type=float, nargs=2, default=[0.01, 0.06])
    rp = sub.add_parser("replicates", help="K conductivity draws at one condition, both viscosity closures")
    rp.add_argument("--K", type=int, required=True)
    rp.add_argument("--post-k", required=True)
    rp.add_argument("--out", required=True)
    rp.add_argument("--seed", type=int, default=1)
    rp.add_argument("--Ra", type=float, required=True)
    rp.add_argument("--Ha", type=float, required=True)
    rp.add_argument("--phi", type=float, required=True)
    r = sub.add_parser("run")
    r.add_argument("--design", required=True)
    r.add_argument("--out", required=True)
    r.add_argument("--workers", type=int, default=2)
    args = ap.parse_args()
    {"design": design, "scenarios": design_scenarios, "replicates": design_replicates, "run": run}[args.cmd](args)


if __name__ == "__main__":
    main()
