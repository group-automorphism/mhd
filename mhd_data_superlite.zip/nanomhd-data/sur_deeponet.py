"""Data-only and physics-informed DeepONet for the MHD nanofluid cavity.

    python3 sur_deeponet.py --name don_data_full  --label-frac 1.0 --lam 0
    python3 sur_deeponet.py --name pidon_full     --label-frac 1.0 --lam 1 --n-unlab 4000

The network maps the parameters (log10 Ra, Ha, phi, k*, mu*) to coefficients b_c(p); the trunk maps (x, y)
to features t_k(x, y); a field is f_c(x, y) = sum_k b_ck t_k(x, y) + b0_c for c = theta, psi, omega.
Because the field is linear in the trunk features, first and second derivatives in x and y are exact and cheap.
With lam > 0 the loss adds the relative residuals of the three governing equations at random collocation
points for the labeled parameters and for extra unlabeled parameter rows that need no solver run.
"""
import argparse, json, pickle, time
import numpy as np
import jax, jax.numpy as jnp, optax
from sur_common import load, split, sample_params, coef_table, PR

P = 64
NF = 16
GRID = 41
xg = np.linspace(0, 1, GRID)
YY, XX = np.meshgrid(xg, xg, indexing="ij")
GRID_PTS = jnp.asarray(np.stack([XX.ravel(), YY.ravel()], -1), jnp.float32)  # (1681, 2) as (x, y)
WALL_PTS = jnp.asarray(np.stack([np.zeros(GRID), xg], -1), jnp.float32)       # x = 0, y varies
EDGES = {  # points on each wall, as (x, y)
    "left": jnp.asarray(np.stack([np.zeros(GRID), xg], -1), jnp.float32),
    "right": jnp.asarray(np.stack([np.ones(GRID), xg], -1), jnp.float32),
    "bottom": jnp.asarray(np.stack([xg, np.zeros(GRID)], -1), jnp.float32),
    "top": jnp.asarray(np.stack([xg, np.ones(GRID)], -1), jnp.float32),
}
IN_MU = np.array([5.0, 50.0, 0.03, 1.1, 1.3], np.float32)
IN_SD = np.array([1.0, 50.0, 0.03, 0.2, 0.3], np.float32)


def init_mlp(key, sizes):
    ps = []
    for i, (a, b) in enumerate(zip(sizes[:-1], sizes[1:])):
        key, k = jax.random.split(key)
        ps.append((jax.random.normal(k, (a, b)) * np.sqrt(1.0 / a), jnp.zeros(b)))
    return ps


def mlp(ps, x):
    for W, b in ps[:-1]:
        x = jnp.tanh(x @ W + b)
    W, b = ps[-1]
    return x @ W + b


def init(key):
    k1, k2, k3, k4 = jax.random.split(key, 4)
    return dict(branch=init_mlp(k1, [5, 128, 128, 128, 3 * P + 3]),
                trunk=init_mlp(k2, [2 + 2 * NF, 128, 128, P]),
                nuhead=init_mlp(k3, [5, 64, 64, 1]),
                B=jax.random.normal(k4, (NF, 2)) * 3.0)


def trunk(params, pt):
    f = 2 * jnp.pi * (params["B"] @ pt)
    z = jnp.concatenate([pt, jnp.sin(f), jnp.cos(f)])
    return jnp.tanh(mlp(params["trunk"], z))


def trunk_derivs(params, pts, order2=True):
    t = lambda pt: trunk(params, pt)
    T = jax.vmap(t)(pts)
    dT = jax.vmap(jax.jacfwd(t))(pts)
    if not order2:
        return T, dT, None
    d2T = jax.vmap(jax.jacfwd(jax.jacfwd(t)))(pts)
    return T, dT, d2T


def coeffs(params, Xn):
    out = jax.vmap(lambda x: mlp(params["branch"], x))(Xn)      # (B, 3P+3)
    return out[:, : 3 * P].reshape(-1, 3, P), out[:, 3 * P:]


def fields_at(Bc, b0, T):
    return jnp.einsum("bcp,np->bnc", Bc, T) + b0[:, None, :]    # (B, n, 3)


def scales(psis):
    return jnp.stack([jnp.ones_like(psis), psis, 20.0 * psis], -1)   # theta, psi, omega scales (B, 3)


def residuals(params, Bc, b0, coef, psis, pts):
    T, dT, d2T = trunk_derivs(params, pts)
    sc = scales(psis)[:, None, :]
    F = fields_at(Bc, b0, T) * sc
    Fx = jnp.einsum("bcp,np->bnc", Bc, dT[:, :, 0]) * sc
    Fy = jnp.einsum("bcp,np->bnc", Bc, dT[:, :, 1]) * sc
    Fxx = jnp.einsum("bcp,np->bnc", Bc, d2T[:, :, 0, 0]) * sc
    Fyy = jnp.einsum("bcp,np->bnc", Bc, d2T[:, :, 1, 1]) * sc
    th_x, th_y, th_xx, th_yy = Fx[..., 0], Fy[..., 0], Fxx[..., 0], Fyy[..., 0]
    ps_x, ps_y, ps_xx, ps_yy = Fx[..., 1], Fy[..., 1], Fxx[..., 1], Fyy[..., 1]
    om, om_x, om_y, om_xx, om_yy = F[..., 2], Fx[..., 2], Fy[..., 2], Fxx[..., 2], Fyy[..., 2]
    c = lambda j: coef[:, j][:, None]
    Ra, Ha, k, rcp, mu, rho, rb, sg = (c(j) for j in range(8))
    u, v = ps_y, -ps_x
    a_T, d_T = u * th_x + v * th_y, (k / rcp) * (th_xx + th_yy)
    a_W, d_W = u * om_x + v * om_y, PR * (mu / rho) * (om_xx + om_yy)
    b_W, l_W = Ra * PR * (rb / rho) * th_x, Ha**2 * PR * (sg / rho) * ps_xx
    terms = [
        (a_T - d_T, jnp.abs(a_T) + jnp.abs(d_T)),
        (a_W - d_W - b_W - l_W, jnp.abs(a_W) + jnp.abs(d_W) + jnp.abs(b_W) + jnp.abs(l_W)),
        (ps_xx + ps_yy + om, jnp.abs(ps_xx + ps_yy) + jnp.abs(om)),
    ]
    out = 0.0
    for r, s in terms:
        s = jax.lax.stop_gradient(jnp.mean(s, axis=1, keepdims=True)) + 1e-3
        out = out + jnp.mean((r / s) ** 2)
    return out


def bc_loss(params, Bc, b0, psis):
    sc = scales(psis)[:, None, :]
    loss = 0.0
    for name, pts in EDGES.items():
        T, dT, _ = trunk_derivs(params, pts, order2=False)
        F = fields_at(Bc, b0, T) * sc
        Fx = jnp.einsum("bcp,np->bnc", Bc, dT[:, :, 0]) * sc
        Fy = jnp.einsum("bcp,np->bnc", Bc, dT[:, :, 1]) * sc
        loss += jnp.mean((F[..., 1] / psis[:, None]) ** 2)                      # psi = 0 on every wall
        if name in ("left", "right"):
            loss += jnp.mean((F[..., 0] - (1.0 if name == "left" else 0.0)) ** 2)
            loss += jnp.mean((Fx[..., 1] / psis[:, None]) ** 2)                 # no slip: psi_x = 0
        else:
            loss += jnp.mean(Fy[..., 0] ** 2)                                   # adiabatic: theta_y = 0
            loss += jnp.mean((Fy[..., 1] / psis[:, None]) ** 2)
    return loss


def nu_from_field(params, Bc, b0, kstar):
    T, dT, _ = trunk_derivs(params, WALL_PTS, order2=False)
    th_x = jnp.einsum("bp,np->bn", Bc[:, 0, :], dT[:, :, 0])
    return -kstar * jnp.trapezoid(th_x, dx=1.0 / (GRID - 1), axis=1)


def loss_fn(params, lab, unlab, coll, lam, w):
    # lab: dict(Xn, coef, psis, theta, psi, lognu); unlab: dict(Xn, coef, psis) or None; coll: points (N, 2)
    Bc, b0 = coeffs(params, lab["Xn"])
    T, _, _ = trunk_derivs(params, GRID_PTS, order2=False)
    F = fields_at(Bc, b0, T)
    l_th = jnp.mean((F[..., 0] - lab["theta"]) ** 2)
    l_ps = jnp.mean((F[..., 1] - lab["psi"]) ** 2)
    nu_f = nu_from_field(params, Bc, b0, lab["coef"][:, 2])
    l_nu = jnp.mean((jnp.log(jnp.maximum(nu_f, 1e-3)) - lab["lognu"]) ** 2)
    l_head = jnp.mean((jax.vmap(lambda x: mlp(params["nuhead"], x))(lab["Xn"])[:, 0] - lab["lognu"]) ** 2)
    data = w["th"] * l_th + w["ps"] * l_ps + w["nu"] * (l_nu + l_head)
    phys = bc = 0.0
    if lam > 0:
        phys = residuals(params, Bc, b0, lab["coef"], lab["psis"], coll)
        bc = bc_loss(params, Bc, b0, lab["psis"])
        if unlab is not None:
            Bu, bu = coeffs(params, unlab["Xn"])
            phys = 0.5 * (phys + residuals(params, Bu, bu, unlab["coef"], unlab["psis"], coll))
            bc = 0.5 * (bc + bc_loss(params, Bu, bu, unlab["psis"]))
    total = data + lam * (phys + w["bc"] * bc)
    return total, dict(th=l_th, ps=l_ps, nu=l_nu, head=l_head, phys=phys, bc=bc)


def fit_psi_scale(X, psi):
    """log max|psi| regressed on simple features; returns a function X -> psi scale."""
    feat = lambda X: np.stack([np.ones(len(X)), X[:, 0], np.log1p(X[:, 1]), X[:, 0] * np.log1p(X[:, 1]),
                               np.log1p(X[:, 1]) ** 2, X[:, 2], X[:, 3], X[:, 4]], 1)
    y = np.log(np.abs(psi).reshape(len(psi), -1).max(1) + 1e-9)
    w = np.linalg.lstsq(feat(X), y, rcond=None)[0]
    return lambda Z: np.exp(feat(Z) @ w).astype(np.float32), float(np.std(y - feat(X) @ w))


def predict(params, X, coef, psis, chunk=64):
    outs = dict(theta=[], psi=[], nu_field=[], nu_head=[])
    Xn = (X - IN_MU) / IN_SD
    T, _, _ = trunk_derivs(params, GRID_PTS, order2=False)
    for i in range(0, len(X), chunk):
        sl = slice(i, i + chunk)
        Bc, b0 = coeffs(params, jnp.asarray(Xn[sl], jnp.float32))
        F = fields_at(Bc, b0, T)
        outs["theta"].append(np.asarray(F[..., 0]).reshape(-1, GRID, GRID))
        outs["psi"].append(np.asarray(F[..., 1] * psis[sl][:, None]).reshape(-1, GRID, GRID))
        outs["nu_field"].append(np.asarray(nu_from_field(params, Bc, b0, jnp.asarray(coef[sl, 2], jnp.float32))))
        outs["nu_head"].append(np.exp(np.asarray(jax.vmap(lambda x: mlp(params["nuhead"], x))(
            jnp.asarray(Xn[sl], jnp.float32))[:, 0])))
    return {k: np.concatenate(v) for k, v in outs.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--label-frac", type=float, default=1.0)
    ap.add_argument("--lam", type=float, default=0.0)
    ap.add_argument("--n-unlab", type=int, default=0)
    ap.add_argument("--steps", type=int, default=6000)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--ncoll", type=int, default=512)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--extrap", action="store_true", help="train on Ha <= 70 only")
    args = ap.parse_args()

    d = load()
    train, test, test_ha, test_rep = split(d, extrap=args.extrap)
    rng = np.random.default_rng(args.seed)
    tr_idx = np.where(train)[0]
    if args.label_frac < 1.0:  # keep whole groups so labels stay paired
        groups = np.unique(d["group"][tr_idx]); rng.shuffle(groups)
        keep = set(groups[: max(1, int(round(args.label_frac * len(groups))))])
        tr_idx = np.array([i for i in tr_idx if d["group"][i] in keep])
    print(f"{args.name}: {len(tr_idx)} labeled cases, lam={args.lam}, unlabeled rows {args.n_unlab}", flush=True)

    psi_fn, psi_resid = fit_psi_scale(d["X"][train], d["psi"][train])
    psis_all = psi_fn(d["X"])
    tn = lambda i: dict(
        Xn=jnp.asarray((d["X"][i] - IN_MU) / IN_SD, jnp.float32), coef=jnp.asarray(d["coef"][i], jnp.float32),
        psis=jnp.asarray(psis_all[i], jnp.float32),
        theta=jnp.asarray(d["theta"][i].reshape(len(i), -1), jnp.float32),
        psi=jnp.asarray((d["psi"][i] / psis_all[i][:, None, None]).reshape(len(i), -1), jnp.float32),
        lognu=jnp.asarray(np.log(d["Nu"][i]), jnp.float32))
    if args.n_unlab > 0:
        Xu = sample_params(args.n_unlab, seed=args.seed + 100)
        Cu, Su = coef_table(Xu), psi_fn(Xu)

    w = dict(th=100.0, ps=100.0, nu=100.0, bc=1.0)
    key = jax.random.PRNGKey(args.seed)
    params = init(key)
    sched = optax.cosine_decay_schedule(args.lr, args.steps, alpha=0.01)
    opt = optax.chain(optax.clip_by_global_norm(5.0), optax.adam(sched))
    state = opt.init(params)

    @jax.jit
    def step(params, state, lab, unlab, coll):
        (l, aux), g = jax.value_and_grad(loss_fn, has_aux=True)(params, lab, unlab, coll, args.lam, w)
        up, state = opt.update(g, state, params)
        return optax.apply_updates(params, up), state, l, aux

    t0 = time.time(); hist = []
    for it in range(args.steps):
        b = rng.choice(tr_idx, size=min(args.batch, len(tr_idx)), replace=False)
        lab = tn(b)
        unlab = None
        if args.lam > 0 and args.n_unlab > 0:
            j = rng.choice(len(Xu), size=args.batch, replace=False)
            unlab = dict(Xn=jnp.asarray((Xu[j] - IN_MU) / IN_SD, jnp.float32), coef=jnp.asarray(Cu[j], jnp.float32),
                         psis=jnp.asarray(Su[j], jnp.float32))
        u = rng.uniform(size=(args.ncoll, 2)); u[args.ncoll // 2:] = rng.beta(0.4, 0.4, size=(args.ncoll - args.ncoll // 2, 2))
        params, state, l, aux = step(params, state, lab, unlab, jnp.asarray(u, jnp.float32))
        if it % 250 == 0 or it == args.steps - 1:
            a = {k: float(v) for k, v in aux.items()}
            hist.append(dict(it=it, loss=float(l), t=round(time.time() - t0), **a))
            print(f"{it:5d} loss {float(l):.4f} th {a['th']:.2e} ps {a['ps']:.2e} nu {a['nu']:.2e} "
                  f"head {a['head']:.2e} phys {a['phys']:.2e} bc {a['bc']:.2e}  {time.time() - t0:.0f}s", flush=True)

    t1 = time.time()
    pred = predict(params, d["X"], d["coef"], psis_all)
    infer = time.time() - t1
    np.savez_compressed(f"outputs/sur/{args.name}_pred.npz", **pred)
    pickle.dump(jax.tree_util.tree_map(np.asarray, params), open(f"outputs/sur/{args.name}_params.pkl", "wb"))
    json.dump(dict(args=vars(args), hist=hist, train_seconds=time.time() - t0, infer_seconds_all=infer,
                   n_cases=len(d["X"]), psi_scale_resid_logsd=psi_resid), open(f"outputs/sur/{args.name}_log.json", "w"))
    print("done", flush=True)


if __name__ == "__main__":
    main()
