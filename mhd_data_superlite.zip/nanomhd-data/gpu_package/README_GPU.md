# GPU run: surrogate comparison, uncertainty maps, spot checks

## What it does

1. **Training.** 12 surrogate variants × 3 seeds (36 models): FNO, PINO, DeepONet and PI-DeepONet, each at
   full labels, at 25% labels, and on the Ha ≤ 70 extrapolation split. The three seeds train in parallel on
   the one GPU.
2. **Evaluation.** Error on held-out design points, on the Ha extrapolation set, and on the three held-out
   replicate conditions, reported as mean ± sd over seeds.
3. **Uncertainty maps.** For Ra = 1e4, 1e5 and 1e6, over Ha from 0 to 100 and φ from 1% to 6%, with 400
   conductivity draws:
   - P(enhancement > 0) under both viscosity closures;
   - the break-even viscosity ratio at which the enhancement vanishes.
4. **Solver spot checks.** About 18 solver runs on the CPU, at viscosity ratios the surrogate never saw, to
   test the maps.

## Requirements

- Linux with an NVIDIA GPU and a working driver: `nvidia-smi` should list the GPU.
- Python 3.10 or newer, with the `venv` module.
- Internet access to PyPI for the install, and about 3 GB of free disk.

## Steps

1. Unzip and enter the folder:
   ```
   unzip mhd_gpu.zip && cd mhd_gpu
   ```
2. Install. This creates `.venv` and checks that JAX sees the GPU. It takes about 5 minutes and should end
   with `devices: [CudaDevice(id=0)]`.
   ```
   ./setup.sh
   ```
3. Run everything. Use `tmux` or `nohup` so the run survives closing the terminal:
   ```
   nohup ./run_all.sh > run.log 2>&1 &
   tail -f run.log
   ```
   Expected time: roughly 1 to 2 hours, depending on the GPU. For an early speed reading, check
   `tail outputs/sur/fno_full_s0.log` after about 5 minutes. Each line shows the step number and the elapsed
   seconds.
4. When `run.log` ends with `Done. Send back: ...`, put `results_gpu.tar.gz` into the connected Drive folder
   or attach it to the chat. It should be about 50 to 70 MB.

## If it stops

Rerun `./run_all.sh`. Finished models are skipped. Failed models are listed in `logs/failed.txt`, with
details in `outputs/sur/<name>.log`.

## If the GPU is not found

1. Run `nvidia-smi`. If it fails, the driver needs fixing first.
2. Force one build, then check again:
   ```
   source .venv/bin/activate
   pip install -U "jax[cuda12]"
   python check_gpu.py
   ```
   For a Blackwell GPU (for example GB10 or RTX 50 series), use `"jax[cuda13]"` instead.
3. If you use conda, create and activate a Python 3.11 environment, then run `./setup.sh` from inside it.

## Settings

| Variable | Default | Effect |
|---|---|---|
| `STEPS` | 20000 | training steps per model |
| `SEEDS` | `"0 1 2"` | seeds; each runs as a parallel process |
| `MAPS_ARGS` | none | for example `--K 1000` for more conductivity draws |
| `SPOT_ARGS` | none | `--quick` runs only the Ra = 1e4 checks |

No credentials or keys are needed.
