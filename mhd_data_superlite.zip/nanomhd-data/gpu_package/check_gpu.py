"""Fails unless JAX sees a GPU (set ALLOW_CPU=1 to skip, for testing only)."""
import os, time
import jax, jax.numpy as jnp
devs = jax.devices()
print("JAX", jax.__version__, "devices:", devs)
if devs[0].platform != "gpu" and os.environ.get("ALLOW_CPU") != "1":
    raise SystemExit("No GPU visible to JAX. See README_GPU.md, section 'If the GPU is not found'.")
x = jnp.ones((4096, 4096)); t = time.time(); (x @ x).block_until_ready(); (x @ x).block_until_ready()
print(f"4096^2 matmul ok, {time.time() - t:.3f}s")
