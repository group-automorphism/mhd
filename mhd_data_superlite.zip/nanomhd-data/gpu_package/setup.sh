#!/usr/bin/env bash
# Creates .venv, installs JAX with GPU support, and checks that JAX sees the GPU.
set -euo pipefail
cd "$(dirname "$0")"
PY=${PYTHON:-python3}
$PY -c 'import sys; assert sys.version_info >= (3, 10), "Python 3.10 or newer is needed"'
$PY -m venv .venv
source .venv/bin/activate
pip install -q -U pip
pip install -q numpy scipy optax
# Newer GPUs (Blackwell) need the CUDA 13 build; older ones work with CUDA 12. Try 13, fall back to 12.
for extra in cuda13 cuda12; do
  echo "Installing jax[$extra] ..."
  if pip install -q -U "jax[$extra]" && python -c 'import jax,sys; sys.exit(0 if jax.devices()[0].platform=="gpu" else 1)' 2>/dev/null; then
    echo "GPU build OK: jax[$extra]"; break
  fi
  echo "jax[$extra] did not give a GPU device, trying the next build"
done
python check_gpu.py
