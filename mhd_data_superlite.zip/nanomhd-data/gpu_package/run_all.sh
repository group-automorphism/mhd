#!/usr/bin/env bash
# Full GPU run: 12 surrogate variants x 3 seeds, evaluation, uncertainty maps, solver spot checks, results archive.
# Safe to rerun: finished models are skipped.  Settings: STEPS (default 20000), SEEDS (default "0 1 2").
set -uo pipefail
cd "$(dirname "$0")"
source .venv/bin/activate
export XLA_PYTHON_CLIENT_PREALLOCATE=false        # several training processes share the GPU
export JAX_DEFAULT_MATMUL_PRECISION=highest       # full fp32 matmuls; the PDE residuals need it
STEPS=${STEPS:-20000}; SEEDS=${SEEDS:-"0 1 2"}
mkdir -p outputs/sur logs
python check_gpu.py || exit 1
START=$(date +%s)

train_seed() {
  local s=$1
  run() { local name=$1 script=$2; shift 2
    [ -f outputs/sur/${name}_pred.npz ] && return 0
    echo "$(date +%T) start $name"
    python $script --name $name --steps $STEPS --seed $s "$@" > outputs/sur/$name.log 2>&1 \
      && echo "$(date +%T) done  $name" || echo "$(date +%T) FAILED $name (see outputs/sur/$name.log)" | tee -a logs/failed.txt
  }
  run fno_full_s$s      sur_pino.py     --label-frac 1.0  --lam 0
  run pino_full_s$s     sur_pino.py     --label-frac 1.0  --lam 1 --n-unlab 4000
  run fno_q25_s$s       sur_pino.py     --label-frac 0.25 --lam 0
  run pino_q25_s$s      sur_pino.py     --label-frac 0.25 --lam 1 --n-unlab 4000
  run fno_full_ex_s$s   sur_pino.py     --label-frac 1.0  --lam 0 --extrap
  run pino_full_ex_s$s  sur_pino.py     --label-frac 1.0  --lam 1 --n-unlab 4000 --extrap
  run don_full_s$s      sur_deeponet.py --label-frac 1.0  --lam 0
  run pidon_full_s$s    sur_deeponet.py --label-frac 1.0  --lam 1 --n-unlab 4000
  run don_q25_s$s       sur_deeponet.py --label-frac 0.25 --lam 0
  run pidon_q25_s$s     sur_deeponet.py --label-frac 0.25 --lam 1 --n-unlab 4000
  run don_full_ex_s$s   sur_deeponet.py --label-frac 1.0  --lam 0 --extrap
  run pidon_full_ex_s$s sur_deeponet.py --label-frac 1.0  --lam 1 --n-unlab 4000 --extrap
}

echo "== 1/4 training (seeds run in parallel) =="
for s in $SEEDS; do train_seed $s > logs/train_seed$s.txt 2>&1 & done
wait
cat logs/train_seed*.txt

echo "== 2/4 evaluation =="
MODELS=$(ls outputs/sur/*_pred.npz | xargs -n1 basename | sed 's/_pred.npz//')
python sur_eval.py $MODELS > outputs/sur/eval_table.txt && python sur_summary.py | tee outputs/sur/summary_table.txt

FNO=$(for s in $SEEDS; do [ -f outputs/sur/fno_full_s${s}_params.pkl ] && echo fno_full_s$s; done)
echo "== 3/4 uncertainty maps ($FNO) =="
python sur_maps.py --models $FNO ${MAPS_ARGS:-} 2>&1 | tee logs/maps.txt

echo "== 4/4 solver spot checks =="
python spot_checks.py --models $FNO --workers $(nproc) ${SPOT_ARGS:-} 2>&1 | tee logs/spot_checks.txt

echo "total $(( ($(date +%s) - START) / 60 )) min" | tee logs/total_time.txt
# predictions are not archived (about 10 MB per model and cheap to regenerate from the parameters)
tar czf results_gpu.tar.gz outputs/sur/*.log outputs/sur/*_log.json outputs/sur/fno_full_s*_params.pkl \
  outputs/sur/pino_full_s*_params.pkl outputs/sur/metrics.json outputs/sur/summary.json outputs/sur/*_table.txt \
  outputs/maps.npz outputs/spot_checks.csv logs 2>/dev/null
echo "Done. Send back: $(pwd)/results_gpu.tar.gz ($(du -h results_gpu.tar.gz | cut -f1))"
