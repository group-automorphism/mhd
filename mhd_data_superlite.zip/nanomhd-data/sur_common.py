"""Shared pieces for the surrogate study: data, coefficient tables, splits, finite-difference residuals."""
import numpy as np
from properties import WATER, nanofluid_ratios

PR = WATER.Pr
H = 1.0 / 40  # spacing of the common 41 x 41 grid


def coef_table(X, mu_model_of=None):
    """Columns: Ra, Ha, k*, rcp*, mu*, rho*, rbeta*, sigma* for each input row (logRa, Ha, phi, k*, mu*).
    The four ratios that do not depend on k* and mu* are functions of phi alone."""
    out = np.empty((len(X), 8))
    for i, (lr, ha, phi, k, mu) in enumerate(X):
        p = nanofluid_ratios(float(phi))
        out[i] = [10 ** lr, ha, k, p["rcp"], mu, p["rho"], p["rbeta"], p["sigma"]]
    return out


def load(path="outputs/surrogate_data.npz"):
    """Full dataset with fields if present; otherwise the scalar table outputs/runs.csv (no theta or psi)."""
    import os, csv
    if os.path.exists(path):
        z = np.load(path)
        d = {k: z[k] for k in z.files}
    else:
        rows = list(csv.DictReader(open("outputs/runs.csv")))
        d = dict(X=np.array([[float(r[k]) for k in ("log10_Ra", "Ha", "phi", "k_ratio", "mu_ratio")] for r in rows]),
                 Nu=np.array([float(r["Nu_hot"]) for r in rows]),
                 group=np.array([r["group"] for r in rows]), kind=np.array([r["kind"] for r in rows]),
                 scenario=np.array([r["scenario"] for r in rows]), case=np.array([r["case"] for r in rows]))
    d["coef"] = coef_table(d["X"])
    return d


REP_HELDOUT = ("R1e5_30", "R1e5_60", "R1e6_0")


def split(d, seed=0, test_frac=0.2, extrap=False):
    """Whole groups are held out, so a nanofluid run never sits in train while its water baseline is in test.
    Three replicate conditions (REP_HELDOUT) are always held out as test_rep: the conductivity-spread test at
    Ra, Ha pairs the surrogate never saw. The remaining replicate conditions are used for training.
    extrap=False: test = 20% of main design points drawn at random over the whole box; test_ha is empty.
    extrap=True : train uses main points with Ha <= 70 only; test = 20% of those points; test_ha = every main
                  point with Ha > 70 (extrapolation in Ha)."""
    rng = np.random.default_rng(seed)
    Ha = d["X"][:, 1]
    is_main = np.array([g.startswith("S:") for g in d["group"]])
    groups = np.unique(d["group"][is_main & ((Ha <= 70) | (not extrap))])
    perm = rng.permutation(len(groups))
    test_groups = set(groups[perm[: int(round(test_frac * len(groups)))]])
    test = np.array([g in test_groups for g in d["group"]])
    test_ha = is_main & (Ha > 70) if extrap else np.zeros(len(Ha), bool)
    test_rep = np.array([g in REP_HELDOUT for g in d["group"]])
    train = ~test & ~test_ha & ~test_rep
    return train, test, test_ha, test_rep


def sample_params(n, seed=0, mu_models=("brinkman", "corcione")):
    """Random parameter rows (logRa, Ha, phi, k*, mu*) without any solver run; used for the physics-only loss.
    Conductivity enhancement is scaled by k_scale in [0.3, 1.6], the range spanned by the posterior draws."""
    rng = np.random.default_rng(seed)
    X = np.empty((n, 5))
    for i in range(n):
        phi = 0.0 if rng.random() < 0.05 else rng.uniform(0.01, 0.06)
        p = nanofluid_ratios(phi, mu_model=mu_models[rng.integers(len(mu_models))], k_scale=rng.uniform(0.3, 1.6))
        X[i] = [rng.uniform(4, 6), rng.uniform(0, 100), phi, p["k"], p["mu"]]
    return X


def fd_residuals(theta, psi, omega, coef, h=H):
    """Interior central-difference residuals of the three equations, each normalized by the mean
    absolute size of its terms. Arrays are [..., iy, ix]; coef is [..., 8]."""
    def dx(f):  return (f[..., 1:-1, 2:] - f[..., 1:-1, :-2]) / (2 * h)
    def dy(f):  return (f[..., 2:, 1:-1] - f[..., :-2, 1:-1]) / (2 * h)
    def lap(f): return (f[..., 1:-1, 2:] + f[..., 1:-1, :-2] + f[..., 2:, 1:-1] + f[..., :-2, 1:-1]
                        - 4 * f[..., 1:-1, 1:-1]) / h**2
    def dxx(f): return (f[..., 1:-1, 2:] - 2 * f[..., 1:-1, 1:-1] + f[..., 1:-1, :-2]) / h**2
    c = lambda j: coef[..., j][..., None, None]
    Ra, Ha, k, rcp, mu, rho, rb, sg = (c(j) for j in range(8))
    u, v = dy(psi), -dx(psi)
    t_adv = u * dx(theta) + v * dy(theta); t_dif = (k / rcp) * lap(theta)
    w_adv = u * dx(omega) + v * dy(omega); w_dif = PR * (mu / rho) * lap(omega)
    w_buo = Ra * PR * (rb / rho) * dx(theta); w_lor = -Ha**2 * PR * (sg / rho) * (-dxx(psi))
    r_T = t_adv - t_dif
    r_W = w_adv - w_dif - w_buo - w_lor
    r_P = lap(psi) + omega[..., 1:-1, 1:-1]
    sT = np.abs(t_adv) + np.abs(t_dif)
    sW = np.abs(w_adv) + np.abs(w_dif) + np.abs(w_buo) + np.abs(w_lor)
    sP = np.abs(lap(psi)) + np.abs(omega[..., 1:-1, 1:-1])
    return r_T, r_W, r_P, sT, sW, sP
