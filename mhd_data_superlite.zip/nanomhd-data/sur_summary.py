"""Aggregate outputs/sur/metrics.json over seeds: model names end in _s<seed>; prints mean +- sd per model.
    python sur_summary.py
"""
import json, re
from collections import defaultdict
import numpy as np

m = json.load(open("outputs/sur/metrics.json"))
by = defaultdict(list)
for name, r in m.items():
    by[re.sub(r"_s\d+$", "", name)].append(r)

KEYS = [("theta_relL2_median", 1, "theta L2"), ("psi_relL2_median", 1, "psi L2"),
        ("nu_head_relerr_median", 100, "Nu med %"), ("nu_head_relerr_p90", 100, "Nu p90 %"),
        ("E_mae_points", 1, "E MAE pts"), ("E_sign_agree", 1, "E sign")]
out = {}
print("%-14s %-9s %2s | " % ("model", "split", "n") + " | ".join("%-15s" % k[2] for k in KEYS))
for base in sorted(by):
    runs = by[base]
    for split in ("test", "test_ha", "test_rep"):
        if split not in runs[0]:
            continue
        row = {}
        cells = []
        for key, mult, lab in KEYS:
            v = np.array([r[split][key] for r in runs if key in r[split]]) * mult
            row[key] = (float(v.mean()), float(v.std(ddof=1)) if len(v) > 1 else 0.0)
            cells.append("%6.3f +- %5.3f" % row[key])
        out[f"{base}:{split}"] = row
        print("%-14s %-9s %2d | " % (base, split, len(runs)) + " | ".join(cells))
    rs = [r["rep_spread"] for r in runs]
    rm = np.array([np.mean([v["draw_rmse_points"] for v in x.values()]) for x in rs])
    sd = np.array([np.mean([v["pred_sd"] / v["true_sd"] for v in x.values()]) for x in rs])
    out[f"{base}:rep_spread"] = dict(draw_rmse_points=(float(rm.mean()), float(rm.std(ddof=1)) if len(rm) > 1 else 0.0),
                                     sd_ratio=(float(sd.mean()), float(sd.std(ddof=1)) if len(sd) > 1 else 0.0))
    print("%-14s spread    %2d | draw RMSE %.2f +- %.2f pts, sd ratio %.2f +- %.2f" % (
        base, len(runs), rm.mean(), out[f"{base}:rep_spread"]["draw_rmse_points"][1], sd.mean(),
        out[f"{base}:rep_spread"]["sd_ratio"][1]))
json.dump(out, open("outputs/sur/summary.json", "w"), indent=1)
