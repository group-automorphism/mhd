"""Paired analysis of the scenario ensemble: Nu enhancement over water under two viscosity closures."""
import csv, json, numpy as np
def load(design, d):
    des = {r["case_id"]: r for r in csv.DictReader(open(design))}
    res = {}
    for l in open(f"{d}/results.jsonl"):
        r = json.loads(l)
        if "converged" in r: res[r["case_id"]] = r
    return des, res
def points(design, d):
    des, res = load(design, d)
    P = {}
    for cid, r in des.items():
        P.setdefault(r["point_id"], {})[r["scenario"]] = (r, res[cid]["Nu_hot"])
    return P
if __name__ == "__main__":
    P = points("outputs/design_scen_128.csv", "outputs/ensemble_scen")
    rows = []
    for pid, s in P.items():
        nb = s["base"][1]
        r = s["brinkman"][0]
        rows.append([float(r["Ra"]), float(r["Ha"]), float(r["phi"]), float(r["k_ratio"]),
                     s["brinkman"][1]/nb-1, s["corcione"][1]/nb-1])
    A = np.array(rows); np.save("outputs/scen_table.npy", A)
    Ra, Ha, phi, kr, Eb, Ec = A.T
    print("n points", len(A))
    print("E brinkman: median %.3f, range [%.3f, %.3f]" % (np.median(Eb), Eb.min(), Eb.max()))
    print("E corcione: median %.3f, range [%.3f, %.3f]" % (np.median(Ec), Ec.min(), Ec.max()))
    print("E>0 brinkman: %.2f  corcione: %.2f  both: %.2f  sign differs: %.2f" % ((Eb>0).mean(), (Ec>0).mean(), ((Eb>0)&(Ec>0)).mean(), ((Eb>0)!=(Ec>0)).mean()))
    d = Ec-Eb
    print("Corcione minus Brinkman: median %.3f, 5-95%% [%.3f, %.3f]" % (np.median(d), *np.percentile(d,[5,95])))
    print("k-only bound: (k_ratio-1) median %.3f" % np.median(kr-1))
    # by regime
    for name, m in [("Ha<20", Ha<20), ("20<=Ha<60", (Ha>=20)&(Ha<60)), ("Ha>=60", Ha>=60)]:
        print(f"{name}: n={m.sum()} E_brink med {np.median(Eb[m]):.3f}  E_corc med {np.median(Ec[m]):.3f}  frac E>0 b/c {(Eb[m]>0).mean():.2f}/{(Ec[m]>0).mean():.2f}")
    for name, m in [("Ra<3e4", Ra<3e4), ("3e4-3e5", (Ra>=3e4)&(Ra<3e5)), (">=3e5", Ra>=3e5)]:
        print(f"{name}: n={m.sum()} E_brink med {np.median(Eb[m]):.3f}  E_corc med {np.median(Ec[m]):.3f}  frac E>0 b/c {(Eb[m]>0).mean():.2f}/{(Ec[m]>0).mean():.2f}")
    # replicates
    Pr = points("outputs/design_rep.csv", "outputs/ensemble_rep")
    nb = Pr["rbase"]["base"][1]
    kb = [Pr[k]["brinkman"][1]/nb-1 for k in sorted(Pr) if k!="rbase"]
    kc = [Pr[k]["corcione"][1]/nb-1 for k in sorted(Pr) if k!="rbase"]
    kk = [float(Pr[k]["brinkman"][0]["k_ratio"])-1 for k in sorted(Pr) if k!="rbase"]
    kb, kc, kk = map(np.array, (kb, kc, kk))
    print("\nReplicates (Ra=1e5, Ha=30, phi=0.04, K=%d conductivity draws):" % len(kb))
    print(" k_ratio-1: mean %.3f sd %.3f [%.3f, %.3f]" % (kk.mean(), kk.std(ddof=1), kk.min(), kk.max()))
    print(" E brinkman: mean %.3f sd %.3f, 95%% [%.3f, %.3f]" % (kb.mean(), kb.std(ddof=1), *np.percentile(kb,[2.5,97.5])))
    print(" E corcione: mean %.3f sd %.3f, 95%% [%.3f, %.3f]" % (kc.mean(), kc.std(ddof=1), *np.percentile(kc,[2.5,97.5])))
    print(" paired viscosity effect (corc-brink): mean %.3f sd %.3f" % ((kc-kb).mean(), (kc-kb).std(ddof=1)))
    print(" fraction of draws with E>0: brink %.2f corc %.2f" % ((kb>0).mean(), (kc>0).mean()))
