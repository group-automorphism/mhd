#!/bin/sh
# K=12 conductivity draws at six (Ra, Ha) conditions, phi = 0.04, both viscosity closures
cd /home/claude/mhd_nf
for Ra in 1e4 1e5 1e6; do for Ha in 0 60; do
  tag=Ra${Ra}_Ha${Ha}
  python3 ensemble.py replicates --K 12 --post-k outputs/post_k.npz --Ra $Ra --Ha $Ha --phi 0.04 --seed 7 --out outputs/rep_grid/design_$tag.csv
  python3 ensemble.py run --design outputs/rep_grid/design_$tag.csv --out outputs/rep_grid/$tag --workers 2
done; done
