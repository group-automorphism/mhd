"""Isotherms and streamlines for water and the two nanofluid closures at Ra = 1e5, phi = 4%, one conductivity draw near the median."""
import os; os.makedirs("paper/figs", exist_ok=True)
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sur_common import load
plt.rcParams.update({"font.size": 7.5, "font.family": "serif", "font.serif": ["Times", "Nimbus Roman", "DejaVu Serif"],
                     "mathtext.fontset": "stix", "axes.linewidth": 0.6, "xtick.labelsize": 6.5, "ytick.labelsize": 6.5})
d = load(); x = np.linspace(0, 1, 41)
fig, axs = plt.subplots(2, 3, figsize=(5.4, 3.75), constrained_layout=True)
for r, (g, ha) in enumerate((("R1e5_0", 0), ("R1e5_60", 60))):
    for c, (case, lab) in enumerate(((f"{g}:rbase_base", "water"), (f"{g}:r08_brinkman", "Brinkman"), (f"{g}:r08_corcione", "Corcione"))):
        i = int(np.where(d["case"] == case)[0][0]); ax = axs[r, c]
        th, ps = d["theta"][i], d["psi"][i]
        ax.contour(x, x, th, levels=np.linspace(0.1, 0.9, 9), cmap="coolwarm", linewidths=0.8)
        ax.contour(x, x, -ps, levels=np.linspace(0.5, 12, 12) if ha == 0 else np.linspace(0.25, 2.75, 11), colors="#3d3d3a", linewidths=0.45)
        ax.set_aspect("equal"); ax.set_xticks([0, 0.5, 1]); ax.set_yticks([0, 0.5, 1])
        ttl = f"{lab}, Ha = {ha}" if c == 0 else f"{lab}, Ha = {ha}"
        ax.set_title(f"{ttl}\nNu = {d['Nu'][i]:.2f},  $|\\psi|_{{\\max}}$ = {abs(ps).max():.2f}", fontsize=7)
        if r == 1: ax.set_xlabel("$x$")
        if c == 0: ax.set_ylabel("$y$")
fig.savefig("paper/figs/fig_fields.pdf", bbox_inches="tight"); fig.savefig("paper/figs/fig_fields.png", dpi=220, bbox_inches="tight")
print("ok", d["X"][np.where(d["case"] == "R1e5_0:r08_brinkman")[0][0]])
