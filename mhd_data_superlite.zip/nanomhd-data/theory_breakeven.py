"""Break-even viscosity from the similarity reduction (water runs only) vs the FNO map; plus the closed-form power law."""
import numpy as np
from theory_common import water_interpolant
from scipy.optimize import brentq
from sur_common import load
from properties import nanofluid_ratios

d = load(); co = d["coef"]; base = d["scenario"] == "base"
lnN_g = water_interpolant(d)
lnN = lambda lra, ha: lnN_g(lra, ha)[0]

z = np.load("gpu_results/outputs/maps.npz")
fi = int(np.argmin(np.abs(z["phi"] - 0.04))); phi = float(z["phi"][fi]); kq = z["k_q"][fi]
p = nanofluid_ratios(phi)
rb, rcp, sg = p["rbeta"], p["rcp"], p["sigma"]
print(f"phi={phi}: (rho beta)*={rb:.4f} (rho cp)*={rcp:.4f} sigma*={sg:.4f} k* quantiles {np.round(kq,4)}")

def breakeven(Ra0, Ha0, k):
    g = lambda m: np.log(k) + lnN(np.log10(Ra0 * rb * rcp / (m * k)), Ha0 * np.sqrt(sg / m)) - lnN(np.log10(Ra0), Ha0)
    if g(1.0) <= 0: return 1.0
    if g(2.0) > 0: return np.inf
    return brentq(g, 1.0, 2.0)

out = {}
for r, Ra0 in enumerate(z["Ra"]):
    rows = []
    for h in range(0, len(z["Ha"]), 5):
        Ha0 = z["Ha"][h]
        red = breakeven(Ra0, Ha0, kq[1])
        fno = z["mu_be"][r, h, fi, 1]; fl = z["mu_be_flag"][r, h, fi, 1]
        fno_s = f"{np.nanmean(fno):.3f}" if np.all(fl == 0) else (">2" if np.all(fl == 1) else "mixed")
        rows.append(f"Ha{Ha0:.0f}: red {red if np.isinf(red) else round(red,3)} fno {fno_s}")
    print(f"Ra={Ra0:.0e}  " + " | ".join(rows))
# closed form, Ha = 0, local exponent n
for n in (0.25, 0.29, 0.30, 0.32):
    print(f"power law n={n}: mu*_0 = (rho beta)*(rho cp)* k*^((1-n)/n) = {rb*rcp*kq[1]**((1-n)/n):.3f}")
# linearized criterion coefficients
from properties import WATER, AL2O3
Crb = AL2O3.rho * AL2O3.beta / (WATER.rho * WATER.beta) - 1
Crc = AL2O3.rho * AL2O3.cp / (WATER.rho * WATER.cp) - 1
print(f"C_rho_beta = {Crb:.3f}, C_rho_cp = {Crc:.3f}, sum = {Crb + Crc:.3f}")
print(f"effective C_k at phi=0.04 (median draw): {(kq[1]-1)/phi:.2f}; Brinkman C_mu {(nanofluid_ratios(phi)['mu']-1)/phi:.2f}; "
      f"Corcione C_mu {(nanofluid_ratios(phi, mu_model='corcione')['mu']-1)/phi:.2f}")
