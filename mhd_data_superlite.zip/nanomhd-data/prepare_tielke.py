"""Convert the Tielke et al. supplementary table to the calibrate.py schema.

Source: Tielke, Maas, Castillo, Rezwan, Avila, "Statistical analysis of thermal conductivity
experimentally measured in water-based nanofluids", Proc. R. Soc. A (2021), DOI 10.1098/rspa.2021.0222,
supplementary file rspa20210222_si_005.csv (semicolon separated).

    python3 prepare_tielke.py "/mnt/user-data/uploads/ERL Papers/rspa20210222_si_005.csv" outputs/conductivity_water.csv

Output columns: pub_id, material, base_fluid, T_C, d_p_nm, phi, ratio
phi comes from the 'c /vol%' column divided by 100. Rows where 'c_dez' disagrees with it by more than
5% are dropped, because the source is then ambiguous about the concentration.
pub_id is the first-author label in the file, which groups measurements by source.
"""
import csv
import sys

src, dst = sys.argv[1], sys.argv[2]
with open(src, encoding="utf-8-sig", newline="") as fh:
    rows = list(csv.reader(fh, delimiter=";"))
hdr = [h.strip() for h in rows[0]]
ix = {h: i for i, h in enumerate(hdr)}
need = ["Author", "Material", "d /nm", "c /vol%", "c_dez", "T /K", "keff/kf"]
missing = [n for n in need if n not in ix]
if missing:
    raise SystemExit(f"missing columns {missing}; found {hdr}")

out, mismatch, dropped = [], [], []
for r in rows[1:]:
    if not any(c.strip() for c in r):
        continue
    c_vol = float(r[ix["c /vol%"]])
    c_dez = float(r[ix["c_dez"]])
    if abs(c_vol / 100.0 - c_dez) > 1e-9:
        mismatch.append((r[ix["Author"]], c_vol, c_dez))
        if abs(c_vol / 100.0 - c_dez) / (c_vol / 100.0) > 0.05:
            dropped.append((r[ix["Author"]], c_vol, c_dez))
            continue  # the two concentration columns disagree: ambiguous, so excluded
    out.append(dict(
        pub_id=r[ix["Author"]].strip(),
        material=r[ix["Material"]].strip(),
        base_fluid="water",
        T_C=round(float(r[ix["T /K"]]) - 273.15, 2),
        d_p_nm=float(r[ix["d /nm"]]),
        phi=c_vol / 100.0,
        ratio=float(r[ix["keff/kf"]]),
    ))

with open(dst, "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(out[0]))
    w.writeheader()
    w.writerows(out)

print(f"wrote {len(out)} rows to {dst}")
print(f"c_dez differs from c/100 in {len(mismatch)} rows; {len(dropped)} differ by more than 5% and are dropped")
print("dropped rows (author, c vol%, c_dez):", dropped)
if mismatch:
    rel = [abs(c / 100 - d) / (c / 100) for _, c, d in mismatch]
    print(f"  largest relative difference {max(rel):.1%}; examples: {mismatch[:4]}")
