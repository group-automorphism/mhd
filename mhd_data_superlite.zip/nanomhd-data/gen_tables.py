"""LaTeX tables generated directly from result files (no hand transcription)."""
import os; os.makedirs("paper/tables", exist_ok=True)
import json, re, glob
from collections import defaultdict
import numpy as np

M = json.load(open("gpu_results/outputs/sur/metrics.json"))
by = defaultdict(list)
for name, r in M.items():
    by[re.sub(r"_s\d+$", "", name)].append(r)
T = defaultdict(list)
for f in glob.glob("gpu_results/outputs/sur/*_log.json"):
    l = json.load(open(f)); T[re.sub(r"_s\d+$", "", f.split("/")[-1].replace("_log.json", ""))].append(l["train_seconds"])


def ms(vals, scale=1.0, nd=2):
    v = np.array(vals) * scale
    return f"{v.mean():.{nd}f}{{\\scriptsize$\\pm${v.std(ddof=1):.{nd}f}}}"


def get(base, split, key):
    return [r[split][key] for r in by[base]]


def spread(base, key):
    out = []
    for r in by[base]:
        vals = r["rep_spread"].values()
        out.append(np.mean([v["draw_rmse_points"] for v in vals]) if key == "rmse" else np.mean([v["pred_sd"] / v["true_sd"] for v in vals]))
    return out


NAMES = [("fno", "FNO"), ("pino", "PINO"), ("don", "DeepONet"), ("pidon", "PI-DeepONet")]
lines = []
for lab, frac in (("full", "100\\%"), ("q25", "25\\%")):
    for key, nm in NAMES:
        b = f"{key}_{lab}"
        row = [nm, frac,
               ms(get(b, "test", "theta_relL2_median"), 1e3, 1), ms(get(b, "test", "E_mae_points")),
               ms(get(b, "test_rep", "E_mae_points")), ms(spread(b, "rmse")), ms(spread(b, "sd"))]
        if lab == "full":
            e = f"{key}_full_ex"
            row += [ms(get(e, "test_ha", "theta_relL2_median"), 1e3, 1), ms(get(e, "test_ha", "E_mae_points"))]
        else:
            row += ["--", "--"]
        lines.append(" & ".join(row) + r" \\")
    gp = json.load(open("outputs/gp_baseline.json"))
    if lab == "full":
        f = gp["full"]
        lines.append(" & ".join(["GP, scalar", "100\\%", "--", f"{f['interp'][0]:.2f}", f"{f['rep'][0]:.2f}", f"{f['spread'][0]:.2f}",
                                 f"{f['spread'][1]:.2f}", "--", f"{gp['full_ex']['ha'][0]:.2f}"]) + r" \\")
        lines.append(r"\midrule")
    else:
        q = gp["q25"]
        lines.append(" & ".join(["GP, scalar", "25\\%", "--", ms([x["interp"][0] for x in q]), ms([x["rep"][0] for x in q]),
                                 ms([x["spread"][0] for x in q]), ms([x["spread"][1] for x in q]), "--", "--"]) + r" \\")
open("paper/tables/surrogates_main.tex", "w").write("\n".join(lines) + "\n")

# appendix: every metric, every split
KEYS = [("theta_relL2_median", 1e3, 1), ("psi_relL2_median", 1e3, 1), ("nu_head_relerr_median", 100, 2),
        ("nu_head_relerr_p90", 100, 2), ("E_mae_points", 1, 2), ("E_sign_agree", 1, 3)]
lines = []
for base in ["fno_full", "pino_full", "don_full", "pidon_full", "fno_q25", "pino_q25", "don_q25", "pidon_q25",
             "fno_full_ex", "pino_full_ex", "don_full_ex", "pidon_full_ex"]:
    nm = dict(NAMES)[base.split("_")[0]]
    lab = {"full": "100\\%", "q25": "25\\%"}[base.split("_")[1]] + (", Ha$\\le$70" if base.endswith("_ex") else "")
    splits = ["test", "test_rep"] + (["test_ha"] if base.endswith("_ex") else [])
    for i, sp in enumerate(splits):
        spn = {"test": "interp.", "test_rep": "replicate", "test_ha": "Ha $>$ 70"}[sp]
        cells = [nm if i == 0 else "", lab if i == 0 else "", spn] + [ms(get(base, sp, k), s, nd) for k, s, nd in KEYS]
        cells.append(f"{np.mean(T[base]):.0f}" if i == 0 else "")
        lines.append(" & ".join(cells) + r" \\")
    lines.append(r"\addlinespace[2pt]")
open("paper/tables/surrogates_full.tex", "w").write("\n".join(lines[:-1]) + "\n")

# replicate blocks from the solver (enhancement statistics)
import csv
from analyze import points
conds = [("outputs/design_rep.csv", "outputs/ensemble_rep", 1e5, 30)] + \
        [(f"outputs/rep_grid/design_Ra{a}_Ha{h}.csv", f"outputs/rep_grid/Ra{a}_Ha{h}", float(a), int(h))
         for a in ("1e4", "1e5", "1e6") for h in ("0", "60")]
rows = []
for des, dd, Ra, Ha in sorted(conds, key=lambda c: (c[3], c[2])):
    P = points(des, dd); nb = P["rbase"]["base"][1]
    ks = [k for k in sorted(P) if k != "rbase"]
    b = 100 * (np.array([P[k]["brinkman"][1] for k in ks]) / nb - 1)
    c = 100 * (np.array([P[k]["corcione"][1] for k in ks]) / nb - 1)
    rows.append(f"$10^{{{int(np.log10(Ra))}}}$ & {Ha} & {len(ks)} & {b.mean():.1f} $\\pm$ {b.std(ddof=1):.1f} & {np.mean(b > 0):.2f} & "
                f"{c.mean():.1f} $\\pm$ {c.std(ddof=1):.1f} & {np.mean(c > 0):.2f} & {np.mean(c - b):+.1f} \\\\")
open("paper/tables/replicates.tex", "w").write("\n".join(rows) + "\n")

# probability-map summary: FNO route and reduction route
z = np.load("gpu_results/outputs/maps.npz"); tm = np.load("outputs/theory_maps.npz")
rows = []
for c, cn in (("brinkman", "Brinkman"), ("corcione", "Corcione")):
    Pf = z[f"P_pos_{c}"].mean(-1); Pr = tm[f"P_{c}"]; ext = tm[f"ext_{c}"]
    for r, Ra in enumerate(z["Ra"]):
        f95, f05 = np.mean(Pf[r] >= 0.95), np.mean(Pf[r] <= 0.05)
        if ext[r].all():
            red = "--"; agree = "--"
        else:
            red = f"{np.mean(Pr[r] >= 0.95):.2f}"
            cl = lambda P: np.digitize(P, [0.05, 0.95])
            agree = f"{np.mean(cl(Pr[r]) == cl(Pf[r])):.2f}"
        rows.append(f"{cn if r == 0 else ''} & $10^{{{int(np.log10(Ra))}}}$ & {f95:.2f} & {1 - f95 - f05:.2f} & {f05:.2f} & {red} & {agree} \\\\")
    rows.append(r"\addlinespace[2pt]")
open("paper/tables/maps.tex", "w").write("\n".join(rows[:-1]) + "\n")
print(open("paper/tables/surrogates_main.tex").read()); print(open("paper/tables/replicates.tex").read()); print(open("paper/tables/maps.tex").read())
