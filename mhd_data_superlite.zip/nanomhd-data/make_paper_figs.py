"""All paper figures in one style (NeurIPS text width 5.5 in). Post-processing of existing results only."""
import os; os.makedirs("paper/figs", exist_ok=True)
import csv
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from theory_common import water_interpolant
from scipy.optimize import brentq
from sur_common import load
from properties import nanofluid_ratios, k_maxwell, WATER, AL2O3
from calibrate import Posterior, property_draws

OUT = "paper/figs"
INK, INK2, GRID = "#0b0b0b", "#52514e", "#dcdbd7"
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
DIV = LinearSegmentedColormap.from_list("div", ["#d03b3b", "#ec9a8f", "#f0efec", "#86b6ef", "#1c5cab"])
plt.rcParams.update({"font.size": 7.5, "axes.titlesize": 7.5, "axes.labelsize": 7.5, "legend.fontsize": 6.5,
                     "xtick.labelsize": 6.5, "ytick.labelsize": 6.5, "axes.edgecolor": INK2, "axes.labelcolor": INK,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
                     "font.family": "serif", "font.serif": ["Times", "Nimbus Roman", "DejaVu Serif"],
                     "mathtext.fontset": "stix", "savefig.facecolor": "white", "axes.linewidth": 0.6,
                     "xtick.major.width": 0.6, "ytick.major.width": 0.6, "legend.frameon": False})


def save(fig, name):
    fig.savefig(f"{OUT}/{name}.pdf", bbox_inches="tight")
    fig.savefig(f"{OUT}/{name}.png", dpi=250, bbox_inches="tight")
    plt.close(fig)


def panel(ax, s):
    ax.text(-0.02, 1.04, s, transform=ax.transAxes, fontsize=8, fontweight="bold", va="bottom", ha="right", color=INK)


# ---------- similarity-reduction interpolant of the water Nusselt function ----------
d = load(); co = d["coef"]; base = d["scenario"] == "base"
lnN = water_interpolant(d)
post = Posterior.load("outputs/post_k.npz", "k")


def breakeven(Ra, Ha, phi, k):
    p = nanofluid_ratios(phi)
    g = lambda m: np.log(k) + lnN(np.log10(Ra * p["rbeta"] * p["rcp"] / (m * k)), Ha * np.sqrt(p["sigma"] / m))[0] \
        - lnN(np.log10(Ra), Ha)[0]
    if g(1.0) <= 0:
        return 1.0
    if g(3.0) > 0:
        return np.nan
    return brentq(g, 1.0, 3.0)


# ---------- Figure 2: property uncertainty and where the closures sit ----------
rows = [r for r in csv.DictReader(open("outputs/conductivity_water.csv"))
        if r["material"] == "Al2O3" and 0.002 <= float(r["phi"]) <= 0.08 and 15 <= float(r["T_C"]) <= 45]
ph = np.array([float(r["phi"]) for r in rows]); kr = np.array([float(r["ratio"]) for r in rows])
labs = len({r["pub_id"] for r in rows})
pg = np.linspace(0.0005, 0.08, 60)
q = np.array([np.percentile(property_draws(post, p, 4000, np.random.default_rng(7))[0], [2.5, 25, 50, 75, 97.5]) for p in pg])
fig, axs = plt.subplots(1, 2, figsize=(5.5, 2.05), constrained_layout=True)
ax = axs[0]
ax.fill_between(100 * pg, q[:, 0], q[:, 4], color="#cde2fb", lw=0, label="new-laboratory 95% band")
ax.fill_between(100 * pg, q[:, 1], q[:, 3], color="#86b6ef", lw=0, label="new-laboratory 50% band")
ax.scatter(100 * ph, kr, s=4, color="#9a9994", lw=0, label=f"measurements ({len(rows)} points, {labs} laboratories)", zorder=3)
ax.plot(100 * pg, q[:, 2], color="#1c5cab", lw=1.4, label="posterior median")
ax.plot(100 * pg, [k_maxwell(p, AL2O3.k, WATER.k) for p in pg], color=INK, lw=0.9, ls="--", label="Maxwell closure")
ax.set_xlim(0, 8); ax.set_ylim(0.97, 1.5)
ax.set_xlabel(r"volume fraction $\varphi$ (%)"); ax.set_ylabel(r"$k^* = k_{nf}/k_f$")
ax.legend(loc="upper left", handlelength=1.4, borderaxespad=0.2)
panel(ax, "a")
ax = axs[1]
phis = np.linspace(0.01, 0.06, 11)
for Ra, col in ((1e5, ORANGE), (1e6, AQUA)):
    be = np.array([[breakeven(Ra, 0.0, p, kq) for kq in np.percentile(property_draws(post, p, 2000, np.random.default_rng(2024))[0], [5, 50, 95])] for p in phis])
    if Ra == 1e6:
        ax.fill_between(100 * phis, be[:, 0], np.where(np.isnan(be[:, 2]), 3.0, be[:, 2]), color=col, alpha=0.18, lw=0,
                        label=r"Ra $=10^6$: conductivity 5-95%")
    ax.plot(100 * phis, be[:, 1], color=col, lw=1.4, label=fr"break-even $\mu^*_0$, Ra $=10^{int(np.log10(Ra))}$, Ha $=0$")
pp = np.linspace(0.01, 0.06, 50)
ax.plot(100 * pp, [nanofluid_ratios(p)["mu"] for p in pp], color=INK, lw=0.9, ls="--", label="Brinkman closure")
ax.plot(100 * pp, [nanofluid_ratios(p, mu_model="corcione")["mu"] for p in pp], color=INK, lw=0.9, ls=":", label=r"Corcione closure, $d_p=33$ nm")
ax.set_xlim(1, 6); ax.set_ylim(1.0, 2.6)
ax.set_xlabel(r"volume fraction $\varphi$ (%)"); ax.set_ylabel(r"viscosity ratio $\mu^* = \mu_{nf}/\mu_f$")
ax.legend(loc="upper left", handlelength=1.6, borderaxespad=0.2)
panel(ax, "b")
save(fig, "fig_properties")

# ---------- Figure 3: probability maps ----------
z = np.load("gpu_results/outputs/maps.npz")
Ras, Has, phiz = z["Ra"], z["Ha"], 100 * z["phi"]
fig, axs = plt.subplots(2, 3, figsize=(5.5, 3.35), sharex=True, sharey=True, constrained_layout=True)
for i, (c, lab) in enumerate((("brinkman", "Brinkman"), ("corcione", "Corcione"))):
    P = z[f"P_pos_{c}"].mean(-1)
    for r in range(3):
        ax = axs[i, r]
        im = ax.pcolormesh(phiz, Has, P[r], cmap=DIV, vmin=0, vmax=1, shading="gouraud", rasterized=True)
        cs = ax.contour(phiz, Has, P[r], levels=[0.05, 0.95], colors=INK, linewidths=[0.6, 0.9], linestyles=["--", "-"])
        ax.clabel(cs, fmt={0.05: "0.05", 0.95: "0.95"}, fontsize=5.5, inline=True)
        ax.spines["top"].set_visible(True); ax.spines["right"].set_visible(True)
        if i == 0:
            ax.set_title(fr"Ra $=10^{int(np.log10(Ras[r]))}$")
        if r == 0:
            ax.set_ylabel(f"{lab}\nHa")
        if i == 1:
            ax.set_xlabel(r"$\varphi$ (%)")
cb = fig.colorbar(im, ax=axs, shrink=0.85, pad=0.015, aspect=30)
cb.set_label(r"$\Pr(\mathrm{Nu}_{nf} > \mathrm{Nu}_f)$", color=INK); cb.outline.set_linewidth(0.5)
save(fig, "fig_maps")

# ---------- Figure 4: theory checks ----------
th = np.load("outputs/theory_reduction.npz")
R = np.load("outputs/theory_elasticity.npy")
fig, axs = plt.subplots(1, 3, figsize=(5.5, 1.95), constrained_layout=True)
ax = axs[0]
m = th["inside"]
for sc, col, lab in (("brinkman", BLUE, "Brinkman"), ("corcione", ORANGE, "Corcione")):
    mm = m & (th["scen"] == sc)
    ax.scatter(100 * th["E_sol"][mm], 100 * th["E_red"][mm], s=5, color=col, lw=0, alpha=0.8, label=lab)
lim = [-12, 27]
ax.plot(lim, lim, color=INK2, lw=0.6); ax.set_xlim(lim); ax.set_ylim(lim)
ax.set_xlabel(r"$E$, solver (%)"); ax.set_ylabel(r"$E$, reduction from water runs (%)")
e = np.abs(100 * (th["E_red"] - th["E_sol"]))[m]
ax.text(0.97, 0.05, f"{m.sum()} runs\nmedian error {np.median(e):.2f} pts", transform=ax.transAxes, ha="right", fontsize=6.2)
ax.legend(loc="upper left", handletextpad=0.2, borderaxespad=0.1, markerscale=1.5)
panel(ax, "a")
ax = axs[1]
ok = R[:, 7] > 0
x = R[ok, 1] / R[ok, 0] ** 0.25
ax.scatter(x, R[ok, 3], s=6, color=BLUE, lw=0, label="solver (paired runs)", zorder=3)
ax.scatter(x, R[ok, 4], s=9, facecolor="none", edgecolor=INK, lw=0.4, label="reduction (water runs)")
ax.axhline(0, color=INK2, lw=0.5)
ax.set_xlabel(r"Ha / Ra$^{1/4}$"); ax.set_ylabel(r"$\partial \ln \mathrm{Nu}_{nf} / \partial \ln \mu^*$")
ax.set_ylim(-0.34, 0.02)
pass  # markers explained in the caption
panel(ax, "b")
ax = axs[2]
fi = int(np.argmin(np.abs(z["phi"] - 0.04)))
kq = z["k_q"][fi]
Hd = np.linspace(0, 100, 51)
for r, (Ra, col) in enumerate(zip(Ras, (BLUE, ORANGE, AQUA))):
    if Ra < 1e5:
        continue  # Ra_nf falls below the range of the water runs at Ra = 1e4
    be = np.array([[breakeven(Ra, h, 0.04, kk) for kk in kq] for h in Hd])
    if Ra == 1e6:
        ax.fill_between(Hd, be[:, 0], np.where(np.isnan(be[:, 2]), 3.0, be[:, 2]), color=col, alpha=0.16, lw=0)
    ax.plot(Hd, be[:, 1], color=col, lw=1.3, label=fr"Ra $=10^{int(np.log10(Ra))}$, reduction")
    mf = np.where((z["mu_be_flag"][r, :, fi, 1] == 0).all(-1), np.nanmean(z["mu_be"][r, :, fi, 1], -1), np.nan)
    ax.plot(Has, mf, color=col, lw=0.8, ls=(0, (2, 1.5)))
ax.plot([], [], color=INK2, lw=0.8, ls=(0, (2, 1.5)), label="FNO surrogate")
# solver anchor: interpolate the spot-check runs at mu* = 1.25 and 1.40, Ha = 0, to E = 0
sp = list(csv.DictReader(open("gpu_results/outputs/spot_checks.csv")))
for Ra, col in ((1e5, ORANGE), (1e6, AQUA)):
    pts = sorted((float(r["mu"]), float(r["E_solver"])) for r in sp if float(r["Ra"]) == Ra and float(r["Ha"]) == 0)
    (m1, e1), (m2, e2) = pts
    ax.scatter([0.8], [m1 + (m2 - m1) * e1 / (e1 - e2)], marker="D", s=14, color=col, edgecolor=INK, lw=0.5, zorder=5, clip_on=False)
ax.scatter([], [], marker="D", s=14, color="white", edgecolor=INK, lw=0.5, label="solver, Ha = 0")
for val, lab, dy in ((nanofluid_ratios(0.04)["mu"], "Brinkman", 0.015), (nanofluid_ratios(0.04, mu_model="corcione")["mu"], "Corcione", 0.015)):
    ax.axhline(val, color=INK2, lw=0.6, ls="--"); ax.text(1.5, val + dy, lab, fontsize=6, color=INK2, ha="left")
ax.set_xlim(0, 100); ax.set_ylim(1.0, 2.0)
ax.set_xlabel("Ha"); ax.set_ylabel(r"break-even $\mu^*_0$, $\varphi = 4\%$")
ax.legend(loc="lower left", bbox_to_anchor=(0.34, 0.125), handlelength=1.2, borderaxespad=0.1, fontsize=5.8, labelspacing=0.3)
panel(ax, "c")
save(fig, "fig_theory")

# ---------- Appendix: spot checks ----------
rows = list(csv.DictReader(open("gpu_results/outputs/spot_checks.csv")))
Es = np.array([float(r["E_solver"]) for r in rows]) * 100; Ep = np.array([float(r["E_sur_mean"]) for r in rows]) * 100
fig, ax = plt.subplots(figsize=(2.3, 2.2), constrained_layout=True)
lim = [min(Es.min(), Ep.min()) - 1.5, max(Es.max(), Ep.max()) + 1.5]
ax.plot(lim, lim, color=INK2, lw=0.6)
ax.scatter(Es, Ep, s=14, color=BLUE, edgecolor="white", lw=0.8, zorder=3)
ax.set_xlim(lim); ax.set_ylim(lim); ax.set_aspect("equal")
ax.set_xlabel(r"$E$, solver (%)"); ax.set_ylabel(r"$E$, FNO (%)")
save(fig, "fig_spotchecks")
print("figures written")
