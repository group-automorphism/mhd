"""Hierarchical Bayesian calibration of nanofluid property closures against public data.

Model (applied separately to conductivity and viscosity), on the log scale:

    log(ratio_ij) = (s + u_j) * x_ij^gamma + e_ij,     x_ij = log(closure(phi_ij))
    u_j ~ N(0, tau^2)      publication (lab) effect on the slope
    e_ij ~ N(0, sigma^2)   within-publication noise
    s   ~ N(s0, ss^2)      slope scale
    gamma ~ Uniform on a grid in [0.2, 1.4]   saturation exponent (gamma < 1: the enhancement
                                               flattens at larger phi, as the literature data do)

closure = Maxwell for conductivity, Brinkman for viscosity. The laboratory effect multiplies the
closure enhancement, so every sampled property curve equals the base fluid at phi = 0 (an
additive offset would not). It carries the between-laboratory scatter that dominates the
literature, which is what the flow ensemble should propagate. One posterior draw defines a
property curve over phi for a "new laboratory" and is mapped to the solver's k_scale / mu_scale hooks.
Draws with a non-positive slope are rejected: a suspension of more conductive (or more viscous)
particles cannot have a property below the base fluid.

Why gamma: with a constant-slope model (gamma = 1) the high slopes reported by laboratories that
measured only at tiny phi dominate the fit and over-predict the property at phi of several percent.

Sampler: partially collapsed Gibbs. gamma is drawn from its marginal with the slope scale and the lab
effects integrated out analytically (a plain Gibbs step for gamma mixes badly because gamma, s and u
are tightly coupled), then s, u and the variances from their conjugate conditionals. No dependencies beyond NumPy.

Input CSV columns (one row per measurement):
    pub_id, phi, ratio            required   (ratio = k_nf/k_f or mu_nf/mu_f)
    material, base_fluid, T_C, d_p_nm   optional, used for filtering only
Usage:
    python3 calibrate.py fit --csv data.csv --property k --material Al2O3 --T-range 15 45 --out outputs/post_k.npz
    python3 calibrate.py selftest
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass

import numpy as np

from properties import AL2O3, k_maxwell, mu_brinkman, WATER

GAMMA_GRID = np.linspace(0.2, 1.4, 25)


@dataclass
class Posterior:
    s: np.ndarray          # (draws,)
    tau: np.ndarray
    sigma: np.ndarray
    gamma: np.ndarray
    u_pub: np.ndarray      # (draws, n_pub) fitted publication effects
    prop: str

    def summary(self) -> dict:
        def q(a):
            lo, med, hi = np.percentile(a, [2.5, 50, 97.5])
            return dict(median=float(med), lo95=float(lo), hi95=float(hi))
        return dict(s=q(self.s), tau=q(self.tau), sigma=q(self.sigma), gamma=q(self.gamma))

    def save(self, path: str):
        np.savez_compressed(path, s=self.s, tau=self.tau, sigma=self.sigma, gamma=self.gamma,
                            u_pub=self.u_pub, prop=self.prop)

    @staticmethod
    def load(path: str, prop: str | None = None) -> "Posterior":
        z = np.load(path, allow_pickle=False)
        gamma = z["gamma"] if "gamma" in z.files else np.ones_like(z["s"])  # files from the gamma = 1 model
        return Posterior(z["s"], z["tau"], z["sigma"], gamma, z["u_pub"], prop or str(z["prop"]))


def closure_log(phi: np.ndarray, prop: str, kp: float = AL2O3.k, kf: float = WATER.k) -> np.ndarray:
    if prop == "k":
        return np.log(np.array([k_maxwell(p, kp, kf) for p in phi]))
    if prop == "mu":
        return np.log(np.array([mu_brinkman(p) for p in phi]))
    raise ValueError(prop)


def fit_hierarchical(
    phi: np.ndarray,
    ratio: np.ndarray,
    pub: np.ndarray,
    prop: str,
    draws: int = 6000,
    burn: int = 1500,
    seed: int = 0,
    s0: float = 1.0,
    ss: float = 1.0,
    ig_a: float = 1.0,
    ig_b: float = 1e-4,
    kp: float = AL2O3.k,
    fit_gamma: bool = True,
) -> Posterior:
    """Gibbs sampler for the model in the module docstring. fit_gamma=False fixes gamma = 1."""
    rng = np.random.default_rng(seed)
    x = closure_log(phi, prop, kp=kp)
    y = np.log(ratio)
    uniq, g = np.unique(pub, return_inverse=True)
    J, N = len(uniq), len(y)
    grid = GAMMA_GRID if fit_gamma else np.array([1.0])
    xg = x[:, None] ** grid[None, :]                       # (N, G)

    # sufficient statistics per publication and per grid value of gamma (constant over the run)
    Mt = np.zeros((J, N))
    Mt[g, np.arange(N)] = 1.0
    Sxx = Mt @ (xg * xg)                    # (J, G)
    Sxy = Mt @ (xg * y[:, None])            # (J, G)
    Syy = Mt @ (y * y)                      # (J,)

    s, tau2, sig2 = 1.0, 0.01, 0.01
    u = np.zeros(J)
    gi = int(np.argmin(np.abs(grid - 1.0)))
    out = dict(s=[], tau=[], sig=[], gam=[], u=[])
    inv_ss2 = 1.0 / ss**2

    for it in range(draws + burn):
        # partially collapsed Gibbs: gamma | (sigma2, tau2) with s and u integrated out,
        # then s | gamma with u integrated out, then u | s, gamma, then the variances.
        D = sig2 + tau2 * Sxx                                   # (J, G)
        A = np.sum(Sxx / D, axis=0)
        B = np.sum(Sxy / D, axis=0)
        C = np.sum((Syy[:, None] - tau2 * Sxy**2 / D) / sig2, axis=0)
        if fit_gamma:
            logml = (-0.5 * np.sum(np.log1p(tau2 * Sxx / sig2), axis=0)
                     - 0.5 * (C + s0**2 * inv_ss2 - (B + s0 * inv_ss2) ** 2 / (A + inv_ss2))
                     - 0.5 * np.log(A + inv_ss2))
            p = np.exp(logml - logml.max())
            gi = int(rng.choice(len(grid), p=p / p.sum()))
        prec_s = A[gi] + inv_ss2
        s = rng.normal((B[gi] + s0 * inv_ss2) / prec_s, 1.0 / np.sqrt(prec_s))
        xe = xg[:, gi]
        prec = Sxx[:, gi] / sig2 + 1.0 / tau2
        u = rng.normal(((Sxy[:, gi] - s * Sxx[:, gi]) / sig2) / prec, 1.0 / np.sqrt(prec))
        e = y - (s + u[g]) * xe
        sig2 = 1.0 / rng.gamma(ig_a + N / 2.0, 1.0 / (ig_b + 0.5 * np.sum(e * e)))
        tau2 = 1.0 / rng.gamma(ig_a + J / 2.0, 1.0 / (ig_b + 0.5 * np.sum(u * u)))
        if it >= burn:
            out["s"].append(s)
            out["tau"].append(np.sqrt(tau2))
            out["sig"].append(np.sqrt(sig2))
            out["gam"].append(grid[gi])
            out["u"].append(u.copy())

    return Posterior(np.array(out["s"]), np.array(out["tau"]), np.array(out["sig"]),
                     np.array(out["gam"]), np.array(out["u"]), prop)


def property_draws(post: Posterior, phi: float, n: int, rng: np.random.Generator, kp: float = AL2O3.k):
    """Draw n property ratios at volume fraction phi for a 'new laboratory'.

    Returns (ratio, scale): ratio is the sampled k_nf/k_f (or mu_nf/mu_f); scale is the equivalent
    k_scale / mu_scale for properties.nanofluid_ratios, i.e. (ratio - 1) / (closure - 1).
    The between-lab slope effect u_new ~ N(0, tau^2) is included; measurement noise is not, because
    the flow model needs the true property of a sample, not a noisy reading. At phi = 0 the ratio is
    exactly 1 for every draw. Draws with slope <= 0 are rejected and redrawn (property >= base fluid).
    """
    idx = rng.integers(0, len(post.s), size=n)
    slope = post.s[idx] + rng.normal(0.0, post.tau[idx])
    for _ in range(200):
        bad = slope <= 0.0
        if not bad.any():
            break
        idx[bad] = rng.integers(0, len(post.s), size=int(bad.sum()))
        slope[bad] = post.s[idx[bad]] + rng.normal(0.0, post.tau[idx[bad]])
    else:
        raise RuntimeError("could not draw positive slopes; the posterior is unusually wide")
    xlog = closure_log(np.array([phi]), post.prop, kp=kp)[0]
    ratio = np.exp(slope * xlog ** post.gamma[idx])
    closure = np.exp(xlog)
    scale = (ratio - 1.0) / (closure - 1.0) if closure > 1.0 + 1e-12 else np.ones(n)
    return ratio, scale


# ----------------------------------------------------------------------------
def selftest(reps: int = 60) -> bool:
    """Parameter recovery and interval coverage on synthetic data with known truth."""
    rng = np.random.default_rng(123)
    truth = dict(s=0.6, tau=0.15, sigma=0.02, gamma=0.6)
    cover = {k: 0 for k in truth}
    for r in range(reps):
        J = 20
        rows = []
        for j in range(J):
            nj = rng.integers(4, 25)
            phi = rng.uniform(0.002, 0.07, nj)
            uj = rng.normal(0, truth["tau"])
            x = closure_log(phi, "k")
            y = (truth["s"] + uj) * x ** truth["gamma"] + rng.normal(0, truth["sigma"], nj)
            rows.append((phi, np.exp(y), np.full(nj, j)))
        phi = np.concatenate([a[0] for a in rows])
        ratio = np.concatenate([a[1] for a in rows])
        pub = np.concatenate([a[2] for a in rows])
        post = fit_hierarchical(phi, ratio, pub, "k", draws=2500, burn=800, seed=r)
        sm = post.summary()
        for key in cover:
            cover[key] += sm[key]["lo95"] <= truth[key] <= sm[key]["hi95"]
    rate = {k: v / reps for k, v in cover.items()}
    print(f"95% interval coverage over {reps} synthetic datasets: "
          + ", ".join(f"{k}={v:.2f}" for k, v in rate.items()))
    ok = all(0.85 <= v <= 1.0 for v in rate.values())
    print("selftest", "PASS" if ok else "FAIL")
    return ok


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    f = sub.add_parser("fit")
    f.add_argument("--csv", required=True)
    f.add_argument("--property", choices=["k", "mu"], required=True)
    f.add_argument("--material", default="Al2O3")
    f.add_argument("--base-fluid", default="water")
    f.add_argument("--phi-min", type=float, default=0.002)
    f.add_argument("--phi-max", type=float, default=0.08)
    f.add_argument("--T-range", type=float, nargs=2, default=None, metavar=("T_MIN_C", "T_MAX_C"),
                   help="keep rows with T_C in this range (needs a T_C column)")
    f.add_argument("--no-gamma", action="store_true", help="fix gamma = 1 (constant-slope model)")
    f.add_argument("--out", required=True)
    sub.add_parser("selftest")
    args = ap.parse_args()

    if args.cmd == "selftest":
        raise SystemExit(0 if selftest() else 1)

    import csv

    with open(args.csv, newline="") as fh:
        rows = list(csv.DictReader(fh))
    keep = []
    for r in rows:
        if r.get("material") and r["material"].strip().lower() != args.material.lower():
            continue
        if r.get("base_fluid") and r["base_fluid"].strip().lower() != args.base_fluid.lower():
            continue
        phi = float(r["phi"])
        if not args.phi_min <= phi <= args.phi_max:
            continue
        if args.T_range is not None:
            if not r.get("T_C"):
                raise SystemExit("--T-range needs a T_C column")
            if not args.T_range[0] <= float(r["T_C"]) <= args.T_range[1]:
                continue
        keep.append(r)
    if len(keep) < 20:
        raise SystemExit(f"only {len(keep)} usable rows after filtering; check column names and filters")
    phi = np.array([float(r["phi"]) for r in keep])
    ratio = np.array([float(r["ratio"]) for r in keep])
    pub = np.array([r["pub_id"] for r in keep])
    post = fit_hierarchical(phi, ratio, pub, args.property, fit_gamma=not args.no_gamma)
    post.save(args.out)
    print(f"{len(keep)} rows from {len(set(pub))} publications")
    for k, v in post.summary().items():
        print(f"  {k:6s} median {v['median']:.4f}  95% [{v['lo95']:.4f}, {v['hi95']:.4f}]")
    print(f"saved {args.out}")


if __name__ == "__main__":
    main()
